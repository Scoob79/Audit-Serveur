﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Principale
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Principale))
        Me.STRATEGIE = New System.Windows.Forms.TabPage()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Label21 = New System.Windows.Forms.Label()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.GROUPES = New System.Windows.Forms.TabPage()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.UTILISATEURS = New System.Windows.Forms.TabPage()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LOGICIELS = New System.Windows.Forms.TabPage()
        Me.ListBox3 = New System.Windows.Forms.ListBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.DataGridView5 = New System.Windows.Forms.DataGridView()
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComboBox3 = New System.Windows.Forms.ComboBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AProposToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LicenceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.SurveillanceToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ActiverToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ListBox4 = New System.Windows.Forms.ListBox()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SERVICES = New System.Windows.Forms.TabPage()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.PILOTES = New System.Windows.Forms.TabPage()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.MAJ = New System.Windows.Forms.TabPage()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.CARTEMERE = New System.Windows.Forms.TabPage()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.POSTE = New System.Windows.Forms.TabPage()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.ComboBox2 = New System.Windows.Forms.ComboBox()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.PROCESSEUR = New System.Windows.Forms.TabPage()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.MEMOIRE = New System.Windows.Forms.TabPage()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.HDD = New System.Windows.Forms.TabPage()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RESEAU = New System.Windows.Forms.TabPage()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.DataGridView6 = New System.Windows.Forms.DataGridView()
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.STRATEGIE.SuspendLayout()
        Me.GROUPES.SuspendLayout()
        Me.UTILISATEURS.SuspendLayout()
        Me.LOGICIELS.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.SERVICES.SuspendLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PILOTES.SuspendLayout()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MAJ.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.CARTEMERE.SuspendLayout()
        Me.POSTE.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.PROCESSEUR.SuspendLayout()
        Me.MEMOIRE.SuspendLayout()
        Me.HDD.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.RESEAU.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage3.SuspendLayout()
        CType(Me.DataGridView6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'STRATEGIE
        '
        Me.STRATEGIE.Controls.Add(Me.TextBox26)
        Me.STRATEGIE.Controls.Add(Me.Label30)
        Me.STRATEGIE.Controls.Add(Me.TextBox18)
        Me.STRATEGIE.Controls.Add(Me.Label22)
        Me.STRATEGIE.Controls.Add(Me.TextBox19)
        Me.STRATEGIE.Controls.Add(Me.Label23)
        Me.STRATEGIE.Controls.Add(Me.TextBox20)
        Me.STRATEGIE.Controls.Add(Me.Label24)
        Me.STRATEGIE.Controls.Add(Me.TextBox21)
        Me.STRATEGIE.Controls.Add(Me.Label25)
        Me.STRATEGIE.Controls.Add(Me.TextBox22)
        Me.STRATEGIE.Controls.Add(Me.Label26)
        Me.STRATEGIE.Controls.Add(Me.TextBox23)
        Me.STRATEGIE.Controls.Add(Me.Label27)
        Me.STRATEGIE.Controls.Add(Me.TextBox24)
        Me.STRATEGIE.Controls.Add(Me.Label28)
        Me.STRATEGIE.Controls.Add(Me.TextBox25)
        Me.STRATEGIE.Controls.Add(Me.Label29)
        Me.STRATEGIE.Location = New System.Drawing.Point(4, 22)
        Me.STRATEGIE.Name = "STRATEGIE"
        Me.STRATEGIE.Size = New System.Drawing.Size(953, 274)
        Me.STRATEGIE.TabIndex = 8
        Me.STRATEGIE.Text = "STRATEGIE"
        Me.STRATEGIE.UseVisualStyleBackColor = True
        '
        'TextBox26
        '
        Me.TextBox26.Location = New System.Drawing.Point(204, 231)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(521, 20)
        Me.TextBox26.TabIndex = 33
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(20, 231)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(73, 13)
        Me.Label30.TabIndex = 32
        Me.Label30.Text = "Rôle du poste"
        '
        'TextBox18
        '
        Me.TextBox18.Location = New System.Drawing.Point(204, 205)
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(521, 20)
        Me.TextBox18.TabIndex = 31
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(20, 205)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(181, 13)
        Me.Label22.TabIndex = 30
        Me.Label22.Text = "Fenêtre d'observation du vérrouillage"
        '
        'TextBox19
        '
        Me.TextBox19.Location = New System.Drawing.Point(204, 179)
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(521, 20)
        Me.TextBox19.TabIndex = 29
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(20, 179)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(108, 13)
        Me.Label23.TabIndex = 28
        Me.Label23.Text = "Durée du vérrouillage"
        '
        'TextBox20
        '
        Me.TextBox20.Location = New System.Drawing.Point(204, 153)
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(521, 20)
        Me.TextBox20.TabIndex = 27
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(20, 153)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(102, 13)
        Me.Label24.TabIndex = 26
        Me.Label24.Text = "Seuil du vérrouillage"
        '
        'TextBox21
        '
        Me.TextBox21.Location = New System.Drawing.Point(204, 127)
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(521, 20)
        Me.TextBox21.TabIndex = 25
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(20, 127)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(169, 13)
        Me.Label25.TabIndex = 24
        Me.Label25.Text = "Nombre de mot de passe anterieur"
        '
        'TextBox22
        '
        Me.TextBox22.Location = New System.Drawing.Point(204, 101)
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(521, 20)
        Me.TextBox22.TabIndex = 23
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(20, 101)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(170, 13)
        Me.Label26.TabIndex = 22
        Me.Label26.Text = "Longueur minimal du mot de passe"
        '
        'TextBox23
        '
        Me.TextBox23.Location = New System.Drawing.Point(204, 75)
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(521, 20)
        Me.TextBox23.TabIndex = 21
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(20, 75)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(134, 13)
        Me.Label27.TabIndex = 20
        Me.Label27.Text = "Mot de passe vie maximale"
        '
        'TextBox24
        '
        Me.TextBox24.Location = New System.Drawing.Point(204, 49)
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(521, 20)
        Me.TextBox24.TabIndex = 19
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(20, 49)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(131, 13)
        Me.Label28.TabIndex = 18
        Me.Label28.Text = "Mot de passe vie minimale"
        '
        'TextBox25
        '
        Me.TextBox25.Location = New System.Drawing.Point(204, 23)
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(521, 20)
        Me.TextBox25.TabIndex = 17
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(20, 23)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(53, 13)
        Me.Label29.TabIndex = 16
        Me.Label29.Text = "Expiration"
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "RedHat.jpg")
        Me.ImageList1.Images.SetKeyName(1, "Suze.png")
        Me.ImageList1.Images.SetKeyName(2, "téléchargement.png")
        Me.ImageList1.Images.SetKeyName(3, "Ubuntu.png")
        Me.ImageList1.Images.SetKeyName(4, "Win 7.jpg")
        Me.ImageList1.Images.SetKeyName(5, "Win 8.jpg")
        Me.ImageList1.Images.SetKeyName(6, "Win 10.jpg")
        Me.ImageList1.Images.SetKeyName(7, "Win 98.jpg")
        Me.ImageList1.Images.SetKeyName(8, "Win Serveur 2.jpg")
        Me.ImageList1.Images.SetKeyName(9, "Win Serveur 2003.png")
        Me.ImageList1.Images.SetKeyName(10, "Win Serveur 2016.jpg")
        Me.ImageList1.Images.SetKeyName(11, "Win Serveur.jpg")
        Me.ImageList1.Images.SetKeyName(12, "Win XP.png")
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(20, 23)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(90, 13)
        Me.Label21.TabIndex = 16
        Me.Label21.Text = "Liste des groupes"
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Location = New System.Drawing.Point(204, 23)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(521, 199)
        Me.ListBox2.TabIndex = 17
        '
        'GROUPES
        '
        Me.GROUPES.Controls.Add(Me.ListBox2)
        Me.GROUPES.Controls.Add(Me.Label21)
        Me.GROUPES.Location = New System.Drawing.Point(4, 22)
        Me.GROUPES.Name = "GROUPES"
        Me.GROUPES.Size = New System.Drawing.Size(953, 274)
        Me.GROUPES.TabIndex = 7
        Me.GROUPES.Text = "GROUPES"
        Me.GROUPES.UseVisualStyleBackColor = True
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(20, 23)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(101, 13)
        Me.Label20.TabIndex = 14
        Me.Label20.Text = "Liste des utilisateurs"
        '
        'Column7
        '
        Me.Column7.HeaderText = "Masque sous réseau"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        '
        'Column8
        '
        Me.Column8.HeaderText = "DHCP"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(204, 23)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(521, 199)
        Me.ListBox1.TabIndex = 15
        '
        'UTILISATEURS
        '
        Me.UTILISATEURS.Controls.Add(Me.ListBox1)
        Me.UTILISATEURS.Controls.Add(Me.Label20)
        Me.UTILISATEURS.Location = New System.Drawing.Point(4, 22)
        Me.UTILISATEURS.Name = "UTILISATEURS"
        Me.UTILISATEURS.Size = New System.Drawing.Size(953, 274)
        Me.UTILISATEURS.TabIndex = 6
        Me.UTILISATEURS.Text = "UTILISATEURS"
        Me.UTILISATEURS.UseVisualStyleBackColor = True
        '
        'Column9
        '
        Me.Column9.HeaderText = "@DHCP"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        '
        'Column10
        '
        Me.Column10.HeaderText = "@DNS"
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        '
        'LOGICIELS
        '
        Me.LOGICIELS.Controls.Add(Me.ListBox3)
        Me.LOGICIELS.Controls.Add(Me.Label31)
        Me.LOGICIELS.Location = New System.Drawing.Point(4, 22)
        Me.LOGICIELS.Name = "LOGICIELS"
        Me.LOGICIELS.Size = New System.Drawing.Size(953, 274)
        Me.LOGICIELS.TabIndex = 9
        Me.LOGICIELS.Text = "LOGICIELS"
        Me.LOGICIELS.UseVisualStyleBackColor = True
        '
        'ListBox3
        '
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.Location = New System.Drawing.Point(204, 23)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(521, 199)
        Me.ListBox3.TabIndex = 17
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(20, 23)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(78, 13)
        Me.Label31.TabIndex = 16
        Me.Label31.Text = "Liste Utilisateur"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label34)
        Me.TabPage2.Controls.Add(Me.DateTimePicker1)
        Me.TabPage2.Controls.Add(Me.DataGridView5)
        Me.TabPage2.Controls.Add(Me.ComboBox3)
        Me.TabPage2.Controls.Add(Me.Label33)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(996, 436)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Comparaison"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(9, 49)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(59, 13)
        Me.Label34.TabIndex = 14
        Me.Label34.Text = "En date du"
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.Location = New System.Drawing.Point(138, 43)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(200, 20)
        Me.DateTimePicker1.TabIndex = 13
        '
        'DataGridView5
        '
        Me.DataGridView5.AllowUserToAddRows = False
        Me.DataGridView5.AllowUserToDeleteRows = False
        Me.DataGridView5.AllowUserToOrderColumns = True
        Me.DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView5.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column12})
        Me.DataGridView5.Location = New System.Drawing.Point(12, 69)
        Me.DataGridView5.Name = "DataGridView5"
        Me.DataGridView5.ReadOnly = True
        Me.DataGridView5.Size = New System.Drawing.Size(963, 350)
        Me.DataGridView5.TabIndex = 12
        '
        'Column12
        '
        Me.Column12.HeaderText = "Champ"
        Me.Column12.Name = "Column12"
        Me.Column12.ReadOnly = True
        '
        'ComboBox3
        '
        Me.ComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(138, 15)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(181, 21)
        Me.ComboBox3.TabIndex = 1
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(9, 18)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(123, 13)
        Me.Label33.TabIndex = 0
        Me.Label33.Text = "Elément de comparaison"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(105, 12)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(205, 21)
        Me.ComboBox1.TabIndex = 6
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.HeaderText = "Installé par"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.ReadOnly = True
        Me.DataGridViewTextBoxColumn22.Width = 150
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.HeaderText = "Date d'installation"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        Me.DataGridViewTextBoxColumn23.ReadOnly = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(17, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Nom du serveur"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AProposToolStripMenuItem, Me.LicenceToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(24, 20)
        Me.ToolStripMenuItem1.Text = "?"
        '
        'AProposToolStripMenuItem
        '
        Me.AProposToolStripMenuItem.Name = "AProposToolStripMenuItem"
        Me.AProposToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.AProposToolStripMenuItem.Text = "A propos"
        '
        'LicenceToolStripMenuItem
        '
        Me.LicenceToolStripMenuItem.Name = "LicenceToolStripMenuItem"
        Me.LicenceToolStripMenuItem.Size = New System.Drawing.Size(122, 22)
        Me.LicenceToolStripMenuItem.Text = "Licence"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.SurveillanceToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1030, 24)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'SurveillanceToolStripMenuItem
        '
        Me.SurveillanceToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ActiverToolStripMenuItem})
        Me.SurveillanceToolStripMenuItem.Name = "SurveillanceToolStripMenuItem"
        Me.SurveillanceToolStripMenuItem.Size = New System.Drawing.Size(82, 20)
        Me.SurveillanceToolStripMenuItem.Text = "Surveillance"
        '
        'ActiverToolStripMenuItem
        '
        Me.ActiverToolStripMenuItem.Name = "ActiverToolStripMenuItem"
        Me.ActiverToolStripMenuItem.Size = New System.Drawing.Size(111, 22)
        Me.ActiverToolStripMenuItem.Text = "Activer"
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.HeaderText = "N° de KB"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.ReadOnly = True
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.HeaderText = "Description"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.ReadOnly = True
        '
        'ListBox4
        '
        Me.ListBox4.FormattingEnabled = True
        Me.ListBox4.Location = New System.Drawing.Point(204, 23)
        Me.ListBox4.Name = "ListBox4"
        Me.ListBox4.Size = New System.Drawing.Size(521, 199)
        Me.ListBox4.TabIndex = 17
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "Poste"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.ReadOnly = True
        '
        'SERVICES
        '
        Me.SERVICES.Controls.Add(Me.DataGridView3)
        Me.SERVICES.Location = New System.Drawing.Point(4, 22)
        Me.SERVICES.Name = "SERVICES"
        Me.SERVICES.Size = New System.Drawing.Size(953, 274)
        Me.SERVICES.TabIndex = 11
        Me.SERVICES.Text = "SERVICES"
        Me.SERVICES.UseVisualStyleBackColor = True
        '
        'DataGridView3
        '
        Me.DataGridView3.AllowUserToAddRows = False
        Me.DataGridView3.AllowUserToDeleteRows = False
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11})
        Me.DataGridView3.Location = New System.Drawing.Point(20, 23)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.ReadOnly = True
        Me.DataGridView3.Size = New System.Drawing.Size(914, 209)
        Me.DataGridView3.TabIndex = 2
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.HeaderText = "Nom"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Width = 150
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.HeaderText = "Descritpion"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Width = 400
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.HeaderText = "Statut"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "Etat"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.HeaderText = "Code Sortie"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(20, 23)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(78, 13)
        Me.Label32.TabIndex = 16
        Me.Label32.Text = "Liste Utilisateur"
        '
        'PILOTES
        '
        Me.PILOTES.Controls.Add(Me.ListBox4)
        Me.PILOTES.Controls.Add(Me.Label32)
        Me.PILOTES.Location = New System.Drawing.Point(4, 22)
        Me.PILOTES.Name = "PILOTES"
        Me.PILOTES.Size = New System.Drawing.Size(953, 274)
        Me.PILOTES.TabIndex = 10
        Me.PILOTES.Text = "PILOTES"
        Me.PILOTES.UseVisualStyleBackColor = True
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.HeaderText = "Nom"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        Me.DataGridViewTextBoxColumn17.Width = 300
        '
        'DataGridView4
        '
        Me.DataGridView4.AllowUserToAddRows = False
        Me.DataGridView4.AllowUserToDeleteRows = False
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18, Me.DataGridViewTextBoxColumn19, Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn23})
        Me.DataGridView4.Location = New System.Drawing.Point(20, 23)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.ReadOnly = True
        Me.DataGridView4.Size = New System.Drawing.Size(914, 209)
        Me.DataGridView4.TabIndex = 2
        '
        'MAJ
        '
        Me.MAJ.Controls.Add(Me.DataGridView4)
        Me.MAJ.Location = New System.Drawing.Point(4, 22)
        Me.MAJ.Name = "MAJ"
        Me.MAJ.Size = New System.Drawing.Size(953, 274)
        Me.MAJ.TabIndex = 12
        Me.MAJ.Text = "MAJ"
        Me.MAJ.UseVisualStyleBackColor = True
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.HeaderText = "@IP"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(731, 23)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(200, 200)
        Me.PictureBox1.TabIndex = 16
        Me.PictureBox1.TabStop = False
        '
        'TextBox8
        '
        Me.TextBox8.Enabled = False
        Me.TextBox8.Location = New System.Drawing.Point(204, 205)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(521, 20)
        Me.TextBox8.TabIndex = 15
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(20, 205)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(42, 13)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "Modèle"
        '
        'TextBox7
        '
        Me.TextBox7.Enabled = False
        Me.TextBox7.Location = New System.Drawing.Point(204, 179)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(521, 20)
        Me.TextBox7.TabIndex = 13
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.HeaderText = "Vitesse Max"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(20, 179)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(57, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Fabriquant"
        '
        'TextBox6
        '
        Me.TextBox6.Enabled = False
        Me.TextBox6.Location = New System.Drawing.Point(204, 153)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(521, 20)
        Me.TextBox6.TabIndex = 11
        '
        'TextBox9
        '
        Me.TextBox9.Enabled = False
        Me.TextBox9.Location = New System.Drawing.Point(204, 75)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(521, 20)
        Me.TextBox9.TabIndex = 11
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(20, 153)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(181, 13)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Numéro du dernier SP Mineur installé"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(20, 75)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(57, 13)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Fabriquant"
        '
        'CARTEMERE
        '
        Me.CARTEMERE.Controls.Add(Me.TextBox9)
        Me.CARTEMERE.Controls.Add(Me.Label11)
        Me.CARTEMERE.Controls.Add(Me.TextBox10)
        Me.CARTEMERE.Controls.Add(Me.Label12)
        Me.CARTEMERE.Controls.Add(Me.TextBox11)
        Me.CARTEMERE.Controls.Add(Me.Label13)
        Me.CARTEMERE.Location = New System.Drawing.Point(4, 22)
        Me.CARTEMERE.Name = "CARTEMERE"
        Me.CARTEMERE.Padding = New System.Windows.Forms.Padding(3)
        Me.CARTEMERE.Size = New System.Drawing.Size(953, 274)
        Me.CARTEMERE.TabIndex = 1
        Me.CARTEMERE.Text = "CARTE-MERE"
        Me.CARTEMERE.UseVisualStyleBackColor = True
        '
        'TextBox10
        '
        Me.TextBox10.Enabled = False
        Me.TextBox10.Location = New System.Drawing.Point(204, 49)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(521, 20)
        Me.TextBox10.TabIndex = 9
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(20, 49)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(42, 13)
        Me.Label12.TabIndex = 8
        Me.Label12.Text = "Modèle"
        '
        'TextBox11
        '
        Me.TextBox11.Enabled = False
        Me.TextBox11.Location = New System.Drawing.Point(204, 23)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(521, 20)
        Me.TextBox11.TabIndex = 7
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(20, 23)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(108, 13)
        Me.Label13.TabIndex = 6
        Me.Label13.Text = "Nom de la carte mère"
        '
        'POSTE
        '
        Me.POSTE.Controls.Add(Me.PictureBox1)
        Me.POSTE.Controls.Add(Me.TextBox8)
        Me.POSTE.Controls.Add(Me.Label9)
        Me.POSTE.Controls.Add(Me.TextBox7)
        Me.POSTE.Controls.Add(Me.Label8)
        Me.POSTE.Controls.Add(Me.TextBox6)
        Me.POSTE.Controls.Add(Me.Label7)
        Me.POSTE.Controls.Add(Me.TextBox5)
        Me.POSTE.Controls.Add(Me.Label6)
        Me.POSTE.Controls.Add(Me.TextBox4)
        Me.POSTE.Controls.Add(Me.Label5)
        Me.POSTE.Controls.Add(Me.TextBox3)
        Me.POSTE.Controls.Add(Me.Label4)
        Me.POSTE.Controls.Add(Me.TextBox2)
        Me.POSTE.Controls.Add(Me.Label3)
        Me.POSTE.Controls.Add(Me.TextBox1)
        Me.POSTE.Controls.Add(Me.Label2)
        Me.POSTE.Location = New System.Drawing.Point(4, 22)
        Me.POSTE.Name = "POSTE"
        Me.POSTE.Padding = New System.Windows.Forms.Padding(3)
        Me.POSTE.Size = New System.Drawing.Size(953, 274)
        Me.POSTE.TabIndex = 0
        Me.POSTE.Text = "POSTE"
        Me.POSTE.UseVisualStyleBackColor = True
        '
        'TextBox5
        '
        Me.TextBox5.Enabled = False
        Me.TextBox5.Location = New System.Drawing.Point(204, 127)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(521, 20)
        Me.TextBox5.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(20, 127)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(181, 13)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Numéro du dernier SP Majeur installé"
        '
        'TextBox4
        '
        Me.TextBox4.Enabled = False
        Me.TextBox4.Location = New System.Drawing.Point(204, 101)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(521, 20)
        Me.TextBox4.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(20, 101)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(42, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Version"
        '
        'TextBox3
        '
        Me.TextBox3.Enabled = False
        Me.TextBox3.Location = New System.Drawing.Point(204, 75)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(521, 20)
        Me.TextBox3.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(20, 75)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(111, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Système d'exploitation"
        '
        'TextBox2
        '
        Me.TextBox2.Enabled = False
        Me.TextBox2.Location = New System.Drawing.Point(204, 49)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(521, 20)
        Me.TextBox2.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(20, 49)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Description du poste"
        '
        'TextBox1
        '
        Me.TextBox1.Enabled = False
        Me.TextBox1.Location = New System.Drawing.Point(204, 23)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(521, 20)
        Me.TextBox1.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(20, 23)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Nom du poste"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Location = New System.Drawing.Point(14, 27)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1004, 462)
        Me.TabControl1.TabIndex = 2
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.ComboBox2)
        Me.TabPage1.Controls.Add(Me.TabControl2)
        Me.TabPage1.Controls.Add(Me.ComboBox1)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(996, 436)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Audit"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(317, 15)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(31, 13)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Audit"
        '
        'ComboBox2
        '
        Me.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Items.AddRange(New Object() {"CR4GI2N2", "DHCPNMS01CHA", "DHCPNMS01VNX", "FSDATANMS01", "FSNMS01CHA", "NA1VM28", "NA1VM29", "NA1VM41", "NA1VM42", "NA1VM43", "NA1VM44", "NA1VM70", "NA2VM28", "NA2VM29", "NA2VM41", "NA2VM42", "NA2VM43", "NA2VM44", "NA2VM70", "NA3VM28", "NA3VM29", "NA3VM40", "NA3VM41", "NA3VM42", "NA3VM43", "NA3VM44", "NA4VM28", "NA4VM29", "NA4VM46", "NA4VM47", "NA4VM48", "NA4VM49", "NA4VM50", "NA4VM70", "NAPRODR4VM28", "NAPRODR4VM29", "NAPRODR4VM47", "NAPRODR4VM48", "NAPRODR4VM49", "NAPRODR4VM50", "NAPRODR4VM70", "NAR4VM18", "NAR4VM19", "NAR4VM23", "NAVSRVM18", "NAVSRVM19", "NAVSRVM23", "NAVSRVM24", "NAVSRVM70", "NMX-1", "NMX-1B", "NMX-2", "NMX-2B", "NMX-3", "NMX-3B", "SNT1WDSC01", "SNT1WEPO01", "SNT1WMAD01", "SNT1WMAD02", "SNT1WPCTRX01", "SNT1WPCTRX02", "SNT1WPDCN01", "SNT1WPDCN02", "SNT1WPPUB01", "SNT1WPPUB02", "SNT1WPSIIV01", "SNT1WPSIIV02", "SNT1WPSTD01", "SNT1WPSTD02", "SNT1WPSTD03", "SNT1WPVEL01", "SNT1WPVEL02", "SNT1WPVMW01", "SNT1WPVMW02", "SNT1WPVWA01", "SNT1WPVWA02", "SNT1WSVM01", "SNT1WSVM02", "SNT1WSVM03", "SNT1WSVM04", "SNT1WSVM05", "SNT1WSVM06", "SNT1WSVM07", "SNT1WSVM08", "SNT1WVAULT01", "SNT1WVEBKP01", "SNT1WVEEAM01", "SNT1WVEMNG01", "SNT1WWDS01", "SNT1WWSUS01", "SNT2WEPO01", "SNT2WMAD01", "SNT2WMAD02", "SNT2WPSTD01", "SNT2WPSTD02", "SNT2WPVWA01", "SNT2WPVWA02", "SNT2WSVM01", "SNT2WSVM02", "SNT2WSVM03", "SNT2WSVM04", "SNT2WSVM05", "SNT2WSVM06", "SNT2WSVM07", "SNT2WSVM08", "SNT2WVAULT01", "SNT2WVEBKP01", "SNT2WVEEAM01", "SNT2WWDS01", "SNT2WWSUS01", "SQLNMS01CHA", "SQLNMS01VNX", "SRV_BABYLON", "SRV_IBO_2", "TLP1WMAD01", "TLP1WMAD02", "TLP1WSUS01", "TLP2WMAD01", "TLP2WMAD02", "TLP2WSUS01", "TRAFFICA02", "TS1PRODR4", "WADNMS01CH", "WADNMS01V", "WALCYON01CH", "WANDREW2CH", "WAVIAT01CH", "WAVIAT02CH", "WAVIAT03CH", "WAVIAT04CH", "WAVM01C", "WCORIGE01CH", "WDEVAUDITDGAC01", "WFHERDS03V", "WFHERDS04V", "WINEM03V", "WINNGI2K03CH", "WNADC1VM28CH", "WRBNDNFV01CH", "WRBNDNFV01V", "WSONHWI01CH", "WSONHWI02CH", "WSONHWI03CH", "WSONHWI04CH", "WSONHWI05CH", "WSONHWI06CH", "WSONHWI07CH", "WSONHWI08CH", "WSONHWI09CH", "WSONHWI10CH", "WSONHWI11CH", "WSONNOK11CH", "WSONNOK12CH", "WSONNOK13CH", "WSONNOK21CH", "WSONNOK22CH", "WSONNOK31CH", "WSONNOK41CH", "WSONNOK42CH", "WSONNOK43CH", "WSONNOK51CH", "WSONNOK52CH", "WSONPORT05CH", "WSONPORT11CH", "WSONUSTSTV", "WSYNCVM03V", "WSYNCVP02V", "WTSASTR02V", "WTSCS2K01CH", "WTSCS2K01V", "WTSINFIXE01CH", "WTSINFIXE01V", "WTSSONUS01CH", "WU2KCP01C", "WVCDB01V", "WVCNTR01V", "WVEEAM01V", "WVEEAM02C", "WVEEAM124CH", "WXMSM05C", "XANMSCPTLV3001", "XANMSCPTLV3002", "XANMSDADSLV3002", "XANMSDADSLV3003", "XANMSDADSLV3105", "XANMSDADSLV3106", "XANMSDESKTV3001", "XANMSDESKTV3002", "XANMSNETACV3001", "XANMSNETACV3002", "XANMSNETACV3003", "XANMSNETACV3004", "XANMSNETACV3005", "XANMSNETACV3006", "XANMSNETACV3007", "XANMSNETACV3008", "XANMSNETACV3009", "XANMSNETACV3010", "XANMSNETACV3011", "XANMSNETACV3012", "XANMSNETACV3013", "XANMSNETACV3014", "XANMSNETACV3015", "XANMSNETACV3016", "XANMSNETACV3017", "XANMSRADIOV3001", "XANMSRADIOV3002", "XANMSRADIOV3003", "XANMSRWIPSV3005", "XANMSRWIPSV3006", "XANMSRWIPSV3008", "XANMSRWIPSV3009", "XANMSRWIPSV3101", "XANMSRWIPSV3102", "XANMSTRANSV3003", "XANMSTRANSV3004", "XANMSTRANSV3101", "XANMSTRANSV3102", "XANMSTRANSV3103", "XANMSTRANSV3104", "XANMSTRSVV3003", "XANMSTRSVV3004", "XANMSTRSVV3005", "XANMSTRSVV3006", "XANMSTRSVV3007", "XANMSU2000V3001", "XANMSU2000V3002", "XANMSU2000V3003", "XANMSU2000V3004", "XANMSU2000V3005", "XANMSU2000V3006", "XANMSU2000V3007", "XANMSU2000V3008", "XANMSU2000V3009", "XANMSU2000V3010", "XANMSVOIXV3003", "XANMSVOIXV3004", "XDDCNMSV01", "XDDCNMSV02", "XDDCNMSV03", "XDDCNMSV04", "XDSFNMSV01", "XDSFNMSV02"})
        Me.ComboBox2.Location = New System.Drawing.Point(354, 12)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(205, 21)
        Me.ComboBox2.TabIndex = 8
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.POSTE)
        Me.TabControl2.Controls.Add(Me.CARTEMERE)
        Me.TabControl2.Controls.Add(Me.PROCESSEUR)
        Me.TabControl2.Controls.Add(Me.MEMOIRE)
        Me.TabControl2.Controls.Add(Me.HDD)
        Me.TabControl2.Controls.Add(Me.RESEAU)
        Me.TabControl2.Controls.Add(Me.UTILISATEURS)
        Me.TabControl2.Controls.Add(Me.GROUPES)
        Me.TabControl2.Controls.Add(Me.STRATEGIE)
        Me.TabControl2.Controls.Add(Me.LOGICIELS)
        Me.TabControl2.Controls.Add(Me.PILOTES)
        Me.TabControl2.Controls.Add(Me.SERVICES)
        Me.TabControl2.Controls.Add(Me.MAJ)
        Me.TabControl2.Location = New System.Drawing.Point(20, 82)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(961, 300)
        Me.TabControl2.TabIndex = 9
        '
        'PROCESSEUR
        '
        Me.PROCESSEUR.Controls.Add(Me.TextBox16)
        Me.PROCESSEUR.Controls.Add(Me.Label18)
        Me.PROCESSEUR.Controls.Add(Me.TextBox15)
        Me.PROCESSEUR.Controls.Add(Me.Label17)
        Me.PROCESSEUR.Controls.Add(Me.TextBox12)
        Me.PROCESSEUR.Controls.Add(Me.Label14)
        Me.PROCESSEUR.Controls.Add(Me.TextBox13)
        Me.PROCESSEUR.Controls.Add(Me.Label15)
        Me.PROCESSEUR.Controls.Add(Me.TextBox14)
        Me.PROCESSEUR.Controls.Add(Me.Label16)
        Me.PROCESSEUR.Location = New System.Drawing.Point(4, 22)
        Me.PROCESSEUR.Name = "PROCESSEUR"
        Me.PROCESSEUR.Size = New System.Drawing.Size(953, 274)
        Me.PROCESSEUR.TabIndex = 2
        Me.PROCESSEUR.Text = "PROCESSEUR"
        Me.PROCESSEUR.UseVisualStyleBackColor = True
        '
        'TextBox16
        '
        Me.TextBox16.Enabled = False
        Me.TextBox16.Location = New System.Drawing.Point(204, 127)
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(521, 20)
        Me.TextBox16.TabIndex = 21
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(20, 127)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(61, 13)
        Me.Label18.TabIndex = 20
        Me.Label18.Text = "Vitesse Min"
        '
        'TextBox15
        '
        Me.TextBox15.Enabled = False
        Me.TextBox15.Location = New System.Drawing.Point(204, 101)
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(521, 20)
        Me.TextBox15.TabIndex = 19
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(20, 101)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(64, 13)
        Me.Label17.TabIndex = 18
        Me.Label17.Text = "Vitesse Max"
        '
        'TextBox12
        '
        Me.TextBox12.Enabled = False
        Me.TextBox12.Location = New System.Drawing.Point(204, 75)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(521, 20)
        Me.TextBox12.TabIndex = 17
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(20, 75)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(60, 13)
        Me.Label14.TabIndex = 16
        Me.Label14.Text = "Description"
        '
        'TextBox13
        '
        Me.TextBox13.Enabled = False
        Me.TextBox13.Location = New System.Drawing.Point(204, 49)
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(521, 20)
        Me.TextBox13.TabIndex = 15
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(20, 49)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(29, 13)
        Me.Label15.TabIndex = 14
        Me.Label15.Text = "Nom"
        '
        'TextBox14
        '
        Me.TextBox14.Enabled = False
        Me.TextBox14.Location = New System.Drawing.Point(204, 23)
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(521, 20)
        Me.TextBox14.TabIndex = 13
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(20, 23)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(31, 13)
        Me.Label16.TabIndex = 12
        Me.Label16.Text = "Type"
        '
        'MEMOIRE
        '
        Me.MEMOIRE.Controls.Add(Me.TextBox17)
        Me.MEMOIRE.Controls.Add(Me.Label19)
        Me.MEMOIRE.Location = New System.Drawing.Point(4, 22)
        Me.MEMOIRE.Name = "MEMOIRE"
        Me.MEMOIRE.Size = New System.Drawing.Size(953, 274)
        Me.MEMOIRE.TabIndex = 3
        Me.MEMOIRE.Text = "MEMOIRE"
        Me.MEMOIRE.UseVisualStyleBackColor = True
        '
        'TextBox17
        '
        Me.TextBox17.Enabled = False
        Me.TextBox17.Location = New System.Drawing.Point(204, 23)
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(521, 20)
        Me.TextBox17.TabIndex = 15
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(20, 23)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(49, 13)
        Me.Label19.TabIndex = 14
        Me.Label19.Text = "Capacité"
        '
        'HDD
        '
        Me.HDD.Controls.Add(Me.DataGridView1)
        Me.HDD.Location = New System.Drawing.Point(4, 22)
        Me.HDD.Name = "HDD"
        Me.HDD.Size = New System.Drawing.Size(953, 274)
        Me.HDD.TabIndex = 4
        Me.HDD.Text = "HDD"
        Me.HDD.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column6})
        Me.DataGridView1.Location = New System.Drawing.Point(20, 23)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(914, 209)
        Me.DataGridView1.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.HeaderText = "Lettre"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 50
        '
        'Column2
        '
        Me.Column2.HeaderText = "Numéro de Série"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 200
        '
        'Column3
        '
        Me.Column3.HeaderText = "Type"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 200
        '
        'Column4
        '
        Me.Column4.HeaderText = "Système de fichier"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'Column5
        '
        Me.Column5.HeaderText = "Espace Libre"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'Column6
        '
        Me.Column6.HeaderText = "Espace Total"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'RESEAU
        '
        Me.RESEAU.Controls.Add(Me.DataGridView2)
        Me.RESEAU.Location = New System.Drawing.Point(4, 22)
        Me.RESEAU.Name = "RESEAU"
        Me.RESEAU.Size = New System.Drawing.Size(953, 274)
        Me.RESEAU.TabIndex = 5
        Me.RESEAU.Text = "RESEAU"
        Me.RESEAU.UseVisualStyleBackColor = True
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.Column7, Me.Column8, Me.Column9, Me.Column10})
        Me.DataGridView2.Location = New System.Drawing.Point(20, 23)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.ReadOnly = True
        Me.DataGridView2.Size = New System.Drawing.Size(914, 209)
        Me.DataGridView2.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "Nom"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "Type"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Description"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "@MAC"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.DataGridView6)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(996, 436)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Surveillance"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'DataGridView6
        '
        Me.DataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView6.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column11, Me.Column13, Me.Column14, Me.Column15, Me.Column16})
        Me.DataGridView6.Location = New System.Drawing.Point(6, 6)
        Me.DataGridView6.Name = "DataGridView6"
        Me.DataGridView6.Size = New System.Drawing.Size(984, 424)
        Me.DataGridView6.TabIndex = 0
        '
        'Column11
        '
        Me.Column11.HeaderText = "#"
        Me.Column11.Name = "Column11"
        Me.Column11.ReadOnly = True
        '
        'Column13
        '
        Me.Column13.HeaderText = "Description"
        Me.Column13.Name = "Column13"
        Me.Column13.ReadOnly = True
        Me.Column13.Width = 500
        '
        'Column14
        '
        Me.Column14.HeaderText = "Date"
        Me.Column14.Name = "Column14"
        '
        'Column15
        '
        Me.Column15.HeaderText = "Heure"
        Me.Column15.Name = "Column15"
        '
        'Column16
        '
        Me.Column16.HeaderText = "Niveau"
        Me.Column16.Name = "Column16"
        Me.Column16.ReadOnly = True
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Principale
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1030, 502)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Principale"
        Me.Text = "Audit"
        Me.STRATEGIE.ResumeLayout(False)
        Me.STRATEGIE.PerformLayout()
        Me.GROUPES.ResumeLayout(False)
        Me.GROUPES.PerformLayout()
        Me.UTILISATEURS.ResumeLayout(False)
        Me.UTILISATEURS.PerformLayout()
        Me.LOGICIELS.ResumeLayout(False)
        Me.LOGICIELS.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.SERVICES.ResumeLayout(False)
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PILOTES.ResumeLayout(False)
        Me.PILOTES.PerformLayout()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MAJ.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.CARTEMERE.ResumeLayout(False)
        Me.CARTEMERE.PerformLayout()
        Me.POSTE.ResumeLayout(False)
        Me.POSTE.PerformLayout()
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.PROCESSEUR.ResumeLayout(False)
        Me.PROCESSEUR.PerformLayout()
        Me.MEMOIRE.ResumeLayout(False)
        Me.MEMOIRE.PerformLayout()
        Me.HDD.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.RESEAU.ResumeLayout(False)
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage3.ResumeLayout(False)
        CType(Me.DataGridView6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents STRATEGIE As System.Windows.Forms.TabPage
    Friend WithEvents TextBox26 As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TextBox18 As System.Windows.Forms.TextBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents TextBox19 As System.Windows.Forms.TextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents TextBox20 As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TextBox21 As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents TextBox22 As System.Windows.Forms.TextBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents TextBox23 As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents TextBox24 As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents TextBox25 As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents GROUPES As System.Windows.Forms.TabPage
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents UTILISATEURS As System.Windows.Forms.TabPage
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LOGICIELS As System.Windows.Forms.TabPage
    Friend WithEvents ListBox3 As System.Windows.Forms.ListBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DataGridView5 As System.Windows.Forms.DataGridView
    Friend WithEvents Column12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComboBox3 As System.Windows.Forms.ComboBox
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents DataGridViewTextBoxColumn22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AProposToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents DataGridViewTextBoxColumn20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ListBox4 As System.Windows.Forms.ListBox
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SERVICES As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents PILOTES As System.Windows.Forms.TabPage
    Friend WithEvents DataGridViewTextBoxColumn17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridView4 As System.Windows.Forms.DataGridView
    Friend WithEvents MAJ As System.Windows.Forms.TabPage
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents CARTEMERE As System.Windows.Forms.TabPage
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents POSTE As System.Windows.Forms.TabPage
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Public WithEvents ComboBox2 As System.Windows.Forms.ComboBox
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents PROCESSEUR As System.Windows.Forms.TabPage
    Friend WithEvents TextBox16 As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TextBox15 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TextBox13 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextBox14 As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents MEMOIRE As System.Windows.Forms.TabPage
    Friend WithEvents TextBox17 As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents HDD As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Column1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents RESEAU As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents LicenceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents DataGridView6 As System.Windows.Forms.DataGridView
    Friend WithEvents Column11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents SurveillanceToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ActiverToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class

﻿Public Class Licence

    Private Sub Licence_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        RichTextBox1.SelectionAlignment = HorizontalAlignment.Center
    End Sub
End Class
﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Principale
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Principale))
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.NsLabel35 = New WindowsApplication1.NSLabel()
        Me.NsOnOffBox1 = New WindowsApplication1.NSOnOffBox()
        Me.NsButton2 = New WindowsApplication1.NSButton()
        Me.NsButton1 = New WindowsApplication1.NSButton()
        Me.NsTabControl2 = New WindowsApplication1.NSTabControl()
        Me.TabPage17 = New System.Windows.Forms.TabPage()
        Me.ComboBox2 = New WindowsApplication1.NSComboBox()
        Me.NsTabControl1 = New WindowsApplication1.NSTabControl()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.NsTextBox1 = New WindowsApplication1.NSTextBox()
        Me.NsLabel37 = New WindowsApplication1.NSLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TextBox8 = New WindowsApplication1.NSTextBox()
        Me.TextBox7 = New WindowsApplication1.NSTextBox()
        Me.TextBox6 = New WindowsApplication1.NSTextBox()
        Me.TextBox5 = New WindowsApplication1.NSTextBox()
        Me.TextBox4 = New WindowsApplication1.NSTextBox()
        Me.TextBox3 = New WindowsApplication1.NSTextBox()
        Me.TextBox2 = New WindowsApplication1.NSTextBox()
        Me.TextBox1 = New WindowsApplication1.NSTextBox()
        Me.NsLabel8 = New WindowsApplication1.NSLabel()
        Me.NsLabel7 = New WindowsApplication1.NSLabel()
        Me.NsLabel4 = New WindowsApplication1.NSLabel()
        Me.NsLabel5 = New WindowsApplication1.NSLabel()
        Me.NsLabel6 = New WindowsApplication1.NSLabel()
        Me.NsLabel3 = New WindowsApplication1.NSLabel()
        Me.NsLabel2 = New WindowsApplication1.NSLabel()
        Me.NsLabel1 = New WindowsApplication1.NSLabel()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.TextBox9 = New WindowsApplication1.NSTextBox()
        Me.TextBox10 = New WindowsApplication1.NSTextBox()
        Me.TextBox11 = New WindowsApplication1.NSTextBox()
        Me.NsLabel9 = New WindowsApplication1.NSLabel()
        Me.NsLabel10 = New WindowsApplication1.NSLabel()
        Me.NsLabel11 = New WindowsApplication1.NSLabel()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.TextBox16 = New WindowsApplication1.NSTextBox()
        Me.TextBox15 = New WindowsApplication1.NSTextBox()
        Me.TextBox12 = New WindowsApplication1.NSTextBox()
        Me.TextBox13 = New WindowsApplication1.NSTextBox()
        Me.TextBox14 = New WindowsApplication1.NSTextBox()
        Me.NsLabel12 = New WindowsApplication1.NSLabel()
        Me.NsLabel13 = New WindowsApplication1.NSLabel()
        Me.NsLabel14 = New WindowsApplication1.NSLabel()
        Me.NsLabel15 = New WindowsApplication1.NSLabel()
        Me.NsLabel16 = New WindowsApplication1.NSLabel()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.TextBox17 = New WindowsApplication1.NSTextBox()
        Me.NsLabel17 = New WindowsApplication1.NSLabel()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column17 = New WindowsApplication1.DataGridViewProgressColumn()
        Me.Column6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.NsLabel18 = New WindowsApplication1.NSLabel()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.NsLabel19 = New WindowsApplication1.NSLabel()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.TextBox26 = New WindowsApplication1.NSTextBox()
        Me.NsLabel28 = New WindowsApplication1.NSLabel()
        Me.TextBox18 = New WindowsApplication1.NSTextBox()
        Me.TextBox19 = New WindowsApplication1.NSTextBox()
        Me.TextBox20 = New WindowsApplication1.NSTextBox()
        Me.TextBox21 = New WindowsApplication1.NSTextBox()
        Me.TextBox22 = New WindowsApplication1.NSTextBox()
        Me.TextBox23 = New WindowsApplication1.NSTextBox()
        Me.TextBox24 = New WindowsApplication1.NSTextBox()
        Me.TextBox25 = New WindowsApplication1.NSTextBox()
        Me.NsLabel20 = New WindowsApplication1.NSLabel()
        Me.NsLabel21 = New WindowsApplication1.NSLabel()
        Me.NsLabel22 = New WindowsApplication1.NSLabel()
        Me.NsLabel23 = New WindowsApplication1.NSLabel()
        Me.NsLabel24 = New WindowsApplication1.NSLabel()
        Me.NsLabel25 = New WindowsApplication1.NSLabel()
        Me.NsLabel26 = New WindowsApplication1.NSLabel()
        Me.NsLabel27 = New WindowsApplication1.NSLabel()
        Me.TabPage13 = New System.Windows.Forms.TabPage()
        Me.ListBox3 = New System.Windows.Forms.ListBox()
        Me.NsLabel29 = New WindowsApplication1.NSLabel()
        Me.TabPage14 = New System.Windows.Forms.TabPage()
        Me.ListBox4 = New System.Windows.Forms.ListBox()
        Me.NsLabel30 = New WindowsApplication1.NSLabel()
        Me.TabPage15 = New System.Windows.Forms.TabPage()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TabPage16 = New System.Windows.Forms.TabPage()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NsLabel34 = New WindowsApplication1.NSLabel()
        Me.ComboBox1 = New WindowsApplication1.NSComboBox()
        Me.NsLabel33 = New WindowsApplication1.NSLabel()
        Me.TabPage18 = New System.Windows.Forms.TabPage()
        Me.ComboBox3 = New WindowsApplication1.NSComboBox()
        Me.DataGridView5 = New System.Windows.Forms.DataGridView()
        Me.Column12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.NsLabel32 = New WindowsApplication1.NSLabel()
        Me.NsLabel31 = New WindowsApplication1.NSLabel()
        Me.TabPage19 = New System.Windows.Forms.TabPage()
        Me.DataGridView6 = New System.Windows.Forms.DataGridView()
        Me.Column11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NsTheme1 = New WindowsApplication1.NSTheme()
        Me.NsLabel38 = New WindowsApplication1.NSLabel()
        Me.NsProgressBar1 = New WindowsApplication1.NSProgressBar()
        Me.NsButton3 = New WindowsApplication1.NSButton()
        Me.NsLabel36 = New WindowsApplication1.NSLabel()
        Me.NsSeperator1 = New WindowsApplication1.NSSeperator()
        Me.NsTabControl2.SuspendLayout()
        Me.TabPage17.SuspendLayout()
        Me.NsTabControl1.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage7.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage9.SuspendLayout()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage10.SuspendLayout()
        Me.TabPage11.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        Me.TabPage13.SuspendLayout()
        Me.TabPage14.SuspendLayout()
        Me.TabPage15.SuspendLayout()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage16.SuspendLayout()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage18.SuspendLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage19.SuspendLayout()
        CType(Me.DataGridView6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.NsTheme1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "RedHat.jpg")
        Me.ImageList1.Images.SetKeyName(1, "Suze.png")
        Me.ImageList1.Images.SetKeyName(2, "téléchargement.png")
        Me.ImageList1.Images.SetKeyName(3, "Ubuntu.png")
        Me.ImageList1.Images.SetKeyName(4, "Win 7.jpg")
        Me.ImageList1.Images.SetKeyName(5, "Win 8.jpg")
        Me.ImageList1.Images.SetKeyName(6, "Win 10.jpg")
        Me.ImageList1.Images.SetKeyName(7, "Win 98.jpg")
        Me.ImageList1.Images.SetKeyName(8, "Win Serveur 2.jpg")
        Me.ImageList1.Images.SetKeyName(9, "Win Serveur 2003.png")
        Me.ImageList1.Images.SetKeyName(10, "Win Serveur 2016.jpg")
        Me.ImageList1.Images.SetKeyName(11, "Win Serveur.jpg")
        Me.ImageList1.Images.SetKeyName(12, "Win XP.png")
        '
        'Timer1
        '
        Me.Timer1.Interval = 60000
        '
        'NsLabel35
        '
        Me.NsLabel35.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel35.Location = New System.Drawing.Point(139, 28)
        Me.NsLabel35.Name = "NsLabel35"
        Me.NsLabel35.Size = New System.Drawing.Size(87, 23)
        Me.NsLabel35.TabIndex = 9
        Me.NsLabel35.Text = "NsLabel35"
        Me.NsLabel35.Value1 = "Surveillance"
        Me.NsLabel35.Value2 = ""
        '
        'NsOnOffBox1
        '
        Me.NsOnOffBox1.Checked = False
        Me.NsOnOffBox1.Location = New System.Drawing.Point(232, 26)
        Me.NsOnOffBox1.MaximumSize = New System.Drawing.Size(56, 24)
        Me.NsOnOffBox1.MinimumSize = New System.Drawing.Size(56, 24)
        Me.NsOnOffBox1.Name = "NsOnOffBox1"
        Me.NsOnOffBox1.Size = New System.Drawing.Size(56, 24)
        Me.NsOnOffBox1.TabIndex = 8
        Me.NsOnOffBox1.Text = "NsOnOffBox1"
        '
        'NsButton2
        '
        Me.NsButton2.Location = New System.Drawing.Point(78, 27)
        Me.NsButton2.Name = "NsButton2"
        Me.NsButton2.Size = New System.Drawing.Size(54, 23)
        Me.NsButton2.TabIndex = 7
        Me.NsButton2.Text = "Licence"
        '
        'NsButton1
        '
        Me.NsButton1.Location = New System.Drawing.Point(13, 28)
        Me.NsButton1.Name = "NsButton1"
        Me.NsButton1.Size = New System.Drawing.Size(59, 23)
        Me.NsButton1.TabIndex = 6
        Me.NsButton1.Text = "A Propos"
        '
        'NsTabControl2
        '
        Me.NsTabControl2.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.NsTabControl2.Controls.Add(Me.TabPage17)
        Me.NsTabControl2.Controls.Add(Me.TabPage18)
        Me.NsTabControl2.Controls.Add(Me.TabPage19)
        Me.NsTabControl2.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed
        Me.NsTabControl2.HotTrack = True
        Me.NsTabControl2.ItemSize = New System.Drawing.Size(28, 115)
        Me.NsTabControl2.Location = New System.Drawing.Point(12, 68)
        Me.NsTabControl2.Multiline = True
        Me.NsTabControl2.Name = "NsTabControl2"
        Me.NsTabControl2.SelectedIndex = 0
        Me.NsTabControl2.Size = New System.Drawing.Size(1167, 462)
        Me.NsTabControl2.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.NsTabControl2.TabIndex = 5
        '
        'TabPage17
        '
        Me.TabPage17.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage17.Controls.Add(Me.ComboBox2)
        Me.TabPage17.Controls.Add(Me.NsTabControl1)
        Me.TabPage17.Controls.Add(Me.NsLabel34)
        Me.TabPage17.Controls.Add(Me.ComboBox1)
        Me.TabPage17.Controls.Add(Me.NsLabel33)
        Me.TabPage17.Location = New System.Drawing.Point(119, 4)
        Me.TabPage17.Name = "TabPage17"
        Me.TabPage17.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage17.Size = New System.Drawing.Size(1044, 454)
        Me.TabPage17.TabIndex = 0
        Me.TabPage17.Text = "Audit"
        '
        'ComboBox2
        '
        Me.ComboBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ComboBox2.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox2.ForeColor = System.Drawing.Color.White
        Me.ComboBox2.FormattingEnabled = True
        Me.ComboBox2.Location = New System.Drawing.Point(399, 12)
        Me.ComboBox2.Name = "ComboBox2"
        Me.ComboBox2.Size = New System.Drawing.Size(224, 21)
        Me.ComboBox2.TabIndex = 4
        '
        'NsTabControl1
        '
        Me.NsTabControl1.Alignment = System.Windows.Forms.TabAlignment.Left
        Me.NsTabControl1.Controls.Add(Me.TabPage4)
        Me.NsTabControl1.Controls.Add(Me.TabPage5)
        Me.NsTabControl1.Controls.Add(Me.TabPage6)
        Me.NsTabControl1.Controls.Add(Me.TabPage7)
        Me.NsTabControl1.Controls.Add(Me.TabPage8)
        Me.NsTabControl1.Controls.Add(Me.TabPage9)
        Me.NsTabControl1.Controls.Add(Me.TabPage10)
        Me.NsTabControl1.Controls.Add(Me.TabPage11)
        Me.NsTabControl1.Controls.Add(Me.TabPage12)
        Me.NsTabControl1.Controls.Add(Me.TabPage13)
        Me.NsTabControl1.Controls.Add(Me.TabPage14)
        Me.NsTabControl1.Controls.Add(Me.TabPage15)
        Me.NsTabControl1.Controls.Add(Me.TabPage16)
        Me.NsTabControl1.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed
        Me.NsTabControl1.ItemSize = New System.Drawing.Size(28, 115)
        Me.NsTabControl1.Location = New System.Drawing.Point(12, 41)
        Me.NsTabControl1.Multiline = True
        Me.NsTabControl1.Name = "NsTabControl1"
        Me.NsTabControl1.SelectedIndex = 0
        Me.NsTabControl1.Size = New System.Drawing.Size(1015, 373)
        Me.NsTabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed
        Me.NsTabControl1.TabIndex = 4
        '
        'TabPage4
        '
        Me.TabPage4.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage4.Controls.Add(Me.NsTextBox1)
        Me.TabPage4.Controls.Add(Me.NsLabel37)
        Me.TabPage4.Controls.Add(Me.PictureBox1)
        Me.TabPage4.Controls.Add(Me.TextBox8)
        Me.TabPage4.Controls.Add(Me.TextBox7)
        Me.TabPage4.Controls.Add(Me.TextBox6)
        Me.TabPage4.Controls.Add(Me.TextBox5)
        Me.TabPage4.Controls.Add(Me.TextBox4)
        Me.TabPage4.Controls.Add(Me.TextBox3)
        Me.TabPage4.Controls.Add(Me.TextBox2)
        Me.TabPage4.Controls.Add(Me.TextBox1)
        Me.TabPage4.Controls.Add(Me.NsLabel8)
        Me.TabPage4.Controls.Add(Me.NsLabel7)
        Me.TabPage4.Controls.Add(Me.NsLabel4)
        Me.TabPage4.Controls.Add(Me.NsLabel5)
        Me.TabPage4.Controls.Add(Me.NsLabel6)
        Me.TabPage4.Controls.Add(Me.NsLabel3)
        Me.TabPage4.Controls.Add(Me.NsLabel2)
        Me.TabPage4.Controls.Add(Me.NsLabel1)
        Me.TabPage4.Location = New System.Drawing.Point(119, 4)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(892, 365)
        Me.TabPage4.TabIndex = 0
        Me.TabPage4.Text = "POSTE"
        '
        'NsTextBox1
        '
        Me.NsTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.NsTextBox1.Location = New System.Drawing.Point(271, 108)
        Me.NsTextBox1.MaxLength = 32767
        Me.NsTextBox1.Multiline = False
        Me.NsTextBox1.Name = "NsTextBox1"
        Me.NsTextBox1.ReadOnly = False
        Me.NsTextBox1.Size = New System.Drawing.Size(405, 23)
        Me.NsTextBox1.TabIndex = 19
        Me.NsTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.NsTextBox1.UseSystemPasswordChar = False
        '
        'NsLabel37
        '
        Me.NsLabel37.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel37.Location = New System.Drawing.Point(6, 108)
        Me.NsLabel37.Name = "NsLabel37"
        Me.NsLabel37.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel37.TabIndex = 18
        Me.NsLabel37.Text = "NsLabel37"
        Me.NsLabel37.Value1 = "Date d'installation"
        Me.NsLabel37.Value2 = " "
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(688, 18)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(193, 182)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 17
        Me.PictureBox1.TabStop = False
        '
        'TextBox8
        '
        Me.TextBox8.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox8.Location = New System.Drawing.Point(271, 200)
        Me.TextBox8.MaxLength = 32767
        Me.TextBox8.Multiline = False
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.ReadOnly = False
        Me.TextBox8.Size = New System.Drawing.Size(405, 23)
        Me.TextBox8.TabIndex = 15
        Me.TextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox8.UseSystemPasswordChar = False
        '
        'TextBox7
        '
        Me.TextBox7.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox7.Location = New System.Drawing.Point(271, 177)
        Me.TextBox7.MaxLength = 32767
        Me.TextBox7.Multiline = False
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.ReadOnly = False
        Me.TextBox7.Size = New System.Drawing.Size(405, 23)
        Me.TextBox7.TabIndex = 14
        Me.TextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox7.UseSystemPasswordChar = False
        '
        'TextBox6
        '
        Me.TextBox6.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox6.Location = New System.Drawing.Point(271, 154)
        Me.TextBox6.MaxLength = 32767
        Me.TextBox6.Multiline = False
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.ReadOnly = False
        Me.TextBox6.Size = New System.Drawing.Size(405, 23)
        Me.TextBox6.TabIndex = 13
        Me.TextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox6.UseSystemPasswordChar = False
        '
        'TextBox5
        '
        Me.TextBox5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox5.Location = New System.Drawing.Point(271, 131)
        Me.TextBox5.MaxLength = 32767
        Me.TextBox5.Multiline = False
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = False
        Me.TextBox5.Size = New System.Drawing.Size(405, 23)
        Me.TextBox5.TabIndex = 12
        Me.TextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox5.UseSystemPasswordChar = False
        '
        'TextBox4
        '
        Me.TextBox4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox4.Location = New System.Drawing.Point(271, 85)
        Me.TextBox4.MaxLength = 32767
        Me.TextBox4.Multiline = False
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = False
        Me.TextBox4.Size = New System.Drawing.Size(405, 23)
        Me.TextBox4.TabIndex = 11
        Me.TextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox4.UseSystemPasswordChar = False
        '
        'TextBox3
        '
        Me.TextBox3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox3.Location = New System.Drawing.Point(271, 64)
        Me.TextBox3.MaxLength = 32767
        Me.TextBox3.Multiline = False
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = False
        Me.TextBox3.Size = New System.Drawing.Size(405, 23)
        Me.TextBox3.TabIndex = 10
        Me.TextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox3.UseSystemPasswordChar = False
        '
        'TextBox2
        '
        Me.TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox2.Location = New System.Drawing.Point(271, 41)
        Me.TextBox2.MaxLength = 32767
        Me.TextBox2.Multiline = False
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = False
        Me.TextBox2.Size = New System.Drawing.Size(405, 23)
        Me.TextBox2.TabIndex = 9
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox2.UseSystemPasswordChar = False
        '
        'TextBox1
        '
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox1.Location = New System.Drawing.Point(271, 18)
        Me.TextBox1.MaxLength = 32767
        Me.TextBox1.Multiline = False
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = False
        Me.TextBox1.Size = New System.Drawing.Size(405, 23)
        Me.TextBox1.TabIndex = 8
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox1.UseSystemPasswordChar = False
        '
        'NsLabel8
        '
        Me.NsLabel8.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel8.Location = New System.Drawing.Point(6, 177)
        Me.NsLabel8.Name = "NsLabel8"
        Me.NsLabel8.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel8.TabIndex = 7
        Me.NsLabel8.Text = "NsLabel8"
        Me.NsLabel8.Value1 = "Fabriquant"
        Me.NsLabel8.Value2 = " "
        '
        'NsLabel7
        '
        Me.NsLabel7.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel7.Location = New System.Drawing.Point(6, 200)
        Me.NsLabel7.Name = "NsLabel7"
        Me.NsLabel7.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel7.TabIndex = 6
        Me.NsLabel7.Text = "NsLabel7"
        Me.NsLabel7.Value1 = "Modèle"
        Me.NsLabel7.Value2 = " "
        '
        'NsLabel4
        '
        Me.NsLabel4.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel4.Location = New System.Drawing.Point(6, 154)
        Me.NsLabel4.Name = "NsLabel4"
        Me.NsLabel4.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel4.TabIndex = 5
        Me.NsLabel4.Text = "NsLabel4"
        Me.NsLabel4.Value1 = "Numéro du dernier SP Mineur installé"
        Me.NsLabel4.Value2 = " "
        '
        'NsLabel5
        '
        Me.NsLabel5.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel5.Location = New System.Drawing.Point(6, 132)
        Me.NsLabel5.Name = "NsLabel5"
        Me.NsLabel5.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel5.TabIndex = 4
        Me.NsLabel5.Text = "NsLabel5"
        Me.NsLabel5.Value1 = "Numéro du dernier SP Majeur installé"
        Me.NsLabel5.Value2 = " "
        '
        'NsLabel6
        '
        Me.NsLabel6.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel6.Location = New System.Drawing.Point(6, 86)
        Me.NsLabel6.Name = "NsLabel6"
        Me.NsLabel6.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel6.TabIndex = 3
        Me.NsLabel6.Text = "NsLabel6"
        Me.NsLabel6.Value1 = "Version"
        Me.NsLabel6.Value2 = " "
        '
        'NsLabel3
        '
        Me.NsLabel3.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel3.Location = New System.Drawing.Point(6, 64)
        Me.NsLabel3.Name = "NsLabel3"
        Me.NsLabel3.Size = New System.Drawing.Size(216, 21)
        Me.NsLabel3.TabIndex = 2
        Me.NsLabel3.Text = "NsLabel3"
        Me.NsLabel3.Value1 = "Système d'exploitation"
        Me.NsLabel3.Value2 = " "
        '
        'NsLabel2
        '
        Me.NsLabel2.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel2.Location = New System.Drawing.Point(6, 41)
        Me.NsLabel2.Name = "NsLabel2"
        Me.NsLabel2.Size = New System.Drawing.Size(216, 17)
        Me.NsLabel2.TabIndex = 1
        Me.NsLabel2.Text = "NsLabel2"
        Me.NsLabel2.Value1 = "Description du poste"
        Me.NsLabel2.Value2 = " "
        '
        'NsLabel1
        '
        Me.NsLabel1.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel1.Location = New System.Drawing.Point(6, 18)
        Me.NsLabel1.Name = "NsLabel1"
        Me.NsLabel1.Size = New System.Drawing.Size(127, 17)
        Me.NsLabel1.TabIndex = 0
        Me.NsLabel1.Text = "Nom du poste"
        Me.NsLabel1.Value1 = "Nom du poste"
        Me.NsLabel1.Value2 = ""
        '
        'TabPage5
        '
        Me.TabPage5.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage5.Controls.Add(Me.TextBox9)
        Me.TabPage5.Controls.Add(Me.TextBox10)
        Me.TabPage5.Controls.Add(Me.TextBox11)
        Me.TabPage5.Controls.Add(Me.NsLabel9)
        Me.TabPage5.Controls.Add(Me.NsLabel10)
        Me.TabPage5.Controls.Add(Me.NsLabel11)
        Me.TabPage5.Location = New System.Drawing.Point(119, 4)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage5.Size = New System.Drawing.Size(892, 365)
        Me.TabPage5.TabIndex = 1
        Me.TabPage5.Text = "CARTE-MERE"
        '
        'TextBox9
        '
        Me.TextBox9.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox9.Location = New System.Drawing.Point(271, 64)
        Me.TextBox9.MaxLength = 32767
        Me.TextBox9.Multiline = False
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.ReadOnly = False
        Me.TextBox9.Size = New System.Drawing.Size(405, 23)
        Me.TextBox9.TabIndex = 16
        Me.TextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox9.UseSystemPasswordChar = False
        '
        'TextBox10
        '
        Me.TextBox10.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox10.Location = New System.Drawing.Point(271, 41)
        Me.TextBox10.MaxLength = 32767
        Me.TextBox10.Multiline = False
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.ReadOnly = False
        Me.TextBox10.Size = New System.Drawing.Size(405, 23)
        Me.TextBox10.TabIndex = 15
        Me.TextBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox10.UseSystemPasswordChar = False
        '
        'TextBox11
        '
        Me.TextBox11.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox11.Location = New System.Drawing.Point(271, 18)
        Me.TextBox11.MaxLength = 32767
        Me.TextBox11.Multiline = False
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.ReadOnly = False
        Me.TextBox11.Size = New System.Drawing.Size(405, 23)
        Me.TextBox11.TabIndex = 14
        Me.TextBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox11.UseSystemPasswordChar = False
        '
        'NsLabel9
        '
        Me.NsLabel9.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel9.Location = New System.Drawing.Point(6, 64)
        Me.NsLabel9.Name = "NsLabel9"
        Me.NsLabel9.Size = New System.Drawing.Size(259, 21)
        Me.NsLabel9.TabIndex = 13
        Me.NsLabel9.Text = "NsLabel9"
        Me.NsLabel9.Value1 = "Fabriquant"
        Me.NsLabel9.Value2 = " "
        '
        'NsLabel10
        '
        Me.NsLabel10.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel10.Location = New System.Drawing.Point(6, 41)
        Me.NsLabel10.Name = "NsLabel10"
        Me.NsLabel10.Size = New System.Drawing.Size(259, 17)
        Me.NsLabel10.TabIndex = 12
        Me.NsLabel10.Text = "NsLabel10"
        Me.NsLabel10.Value1 = "Modèle"
        Me.NsLabel10.Value2 = " "
        '
        'NsLabel11
        '
        Me.NsLabel11.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel11.Location = New System.Drawing.Point(6, 18)
        Me.NsLabel11.Name = "NsLabel11"
        Me.NsLabel11.Size = New System.Drawing.Size(259, 17)
        Me.NsLabel11.TabIndex = 11
        Me.NsLabel11.Text = "Nom de la carte mère"
        Me.NsLabel11.Value1 = "Nom de la carte mère"
        Me.NsLabel11.Value2 = ""
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage6.Controls.Add(Me.TextBox16)
        Me.TabPage6.Controls.Add(Me.TextBox15)
        Me.TabPage6.Controls.Add(Me.TextBox12)
        Me.TabPage6.Controls.Add(Me.TextBox13)
        Me.TabPage6.Controls.Add(Me.TextBox14)
        Me.TabPage6.Controls.Add(Me.NsLabel12)
        Me.TabPage6.Controls.Add(Me.NsLabel13)
        Me.TabPage6.Controls.Add(Me.NsLabel14)
        Me.TabPage6.Controls.Add(Me.NsLabel15)
        Me.TabPage6.Controls.Add(Me.NsLabel16)
        Me.TabPage6.Location = New System.Drawing.Point(119, 4)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Size = New System.Drawing.Size(892, 365)
        Me.TabPage6.TabIndex = 2
        Me.TabPage6.Text = "PROCESSEUR"
        '
        'TextBox16
        '
        Me.TextBox16.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox16.Location = New System.Drawing.Point(273, 102)
        Me.TextBox16.MaxLength = 32767
        Me.TextBox16.Multiline = False
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.ReadOnly = False
        Me.TextBox16.Size = New System.Drawing.Size(405, 23)
        Me.TextBox16.TabIndex = 22
        Me.TextBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox16.UseSystemPasswordChar = False
        '
        'TextBox15
        '
        Me.TextBox15.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox15.Location = New System.Drawing.Point(273, 79)
        Me.TextBox15.MaxLength = 32767
        Me.TextBox15.Multiline = False
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.ReadOnly = False
        Me.TextBox15.Size = New System.Drawing.Size(405, 23)
        Me.TextBox15.TabIndex = 21
        Me.TextBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox15.UseSystemPasswordChar = False
        '
        'TextBox12
        '
        Me.TextBox12.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox12.Location = New System.Drawing.Point(273, 58)
        Me.TextBox12.MaxLength = 32767
        Me.TextBox12.Multiline = False
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.ReadOnly = False
        Me.TextBox12.Size = New System.Drawing.Size(405, 23)
        Me.TextBox12.TabIndex = 20
        Me.TextBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox12.UseSystemPasswordChar = False
        '
        'TextBox13
        '
        Me.TextBox13.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox13.Location = New System.Drawing.Point(273, 35)
        Me.TextBox13.MaxLength = 32767
        Me.TextBox13.Multiline = False
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.ReadOnly = False
        Me.TextBox13.Size = New System.Drawing.Size(405, 23)
        Me.TextBox13.TabIndex = 19
        Me.TextBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox13.UseSystemPasswordChar = False
        '
        'TextBox14
        '
        Me.TextBox14.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox14.Location = New System.Drawing.Point(273, 12)
        Me.TextBox14.MaxLength = 32767
        Me.TextBox14.Multiline = False
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.ReadOnly = False
        Me.TextBox14.Size = New System.Drawing.Size(405, 23)
        Me.TextBox14.TabIndex = 18
        Me.TextBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox14.UseSystemPasswordChar = False
        '
        'NsLabel12
        '
        Me.NsLabel12.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel12.Location = New System.Drawing.Point(6, 108)
        Me.NsLabel12.Name = "NsLabel12"
        Me.NsLabel12.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel12.TabIndex = 17
        Me.NsLabel12.Text = "NsLabel12"
        Me.NsLabel12.Value1 = "Numéro du dernier SP Majeur installé"
        Me.NsLabel12.Value2 = " "
        '
        'NsLabel13
        '
        Me.NsLabel13.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel13.Location = New System.Drawing.Point(6, 85)
        Me.NsLabel13.Name = "NsLabel13"
        Me.NsLabel13.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel13.TabIndex = 16
        Me.NsLabel13.Text = "NsLabel13"
        Me.NsLabel13.Value1 = "Version"
        Me.NsLabel13.Value2 = " "
        '
        'NsLabel14
        '
        Me.NsLabel14.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel14.Location = New System.Drawing.Point(6, 58)
        Me.NsLabel14.Name = "NsLabel14"
        Me.NsLabel14.Size = New System.Drawing.Size(216, 21)
        Me.NsLabel14.TabIndex = 15
        Me.NsLabel14.Text = "NsLabel14"
        Me.NsLabel14.Value1 = "Système d'exploitation"
        Me.NsLabel14.Value2 = " "
        '
        'NsLabel15
        '
        Me.NsLabel15.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel15.Location = New System.Drawing.Point(6, 41)
        Me.NsLabel15.Name = "NsLabel15"
        Me.NsLabel15.Size = New System.Drawing.Size(216, 17)
        Me.NsLabel15.TabIndex = 14
        Me.NsLabel15.Text = "NsLabel15"
        Me.NsLabel15.Value1 = "Description du poste"
        Me.NsLabel15.Value2 = " "
        '
        'NsLabel16
        '
        Me.NsLabel16.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel16.Location = New System.Drawing.Point(6, 18)
        Me.NsLabel16.Name = "NsLabel16"
        Me.NsLabel16.Size = New System.Drawing.Size(127, 17)
        Me.NsLabel16.TabIndex = 13
        Me.NsLabel16.Text = "Nom du poste"
        Me.NsLabel16.Value1 = "Nom du poste"
        Me.NsLabel16.Value2 = ""
        '
        'TabPage7
        '
        Me.TabPage7.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage7.Controls.Add(Me.TextBox17)
        Me.TabPage7.Controls.Add(Me.NsLabel17)
        Me.TabPage7.Location = New System.Drawing.Point(119, 4)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Size = New System.Drawing.Size(892, 365)
        Me.TabPage7.TabIndex = 3
        Me.TabPage7.Text = "MEMOIRE"
        '
        'TextBox17
        '
        Me.TextBox17.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox17.Location = New System.Drawing.Point(273, 12)
        Me.TextBox17.MaxLength = 32767
        Me.TextBox17.Multiline = False
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.ReadOnly = False
        Me.TextBox17.Size = New System.Drawing.Size(405, 23)
        Me.TextBox17.TabIndex = 20
        Me.TextBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox17.UseSystemPasswordChar = False
        '
        'NsLabel17
        '
        Me.NsLabel17.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel17.Location = New System.Drawing.Point(6, 18)
        Me.NsLabel17.Name = "NsLabel17"
        Me.NsLabel17.Size = New System.Drawing.Size(127, 17)
        Me.NsLabel17.TabIndex = 19
        Me.NsLabel17.Text = "Nom du poste"
        Me.NsLabel17.Value1 = "Nom du poste"
        Me.NsLabel17.Value2 = ""
        '
        'TabPage8
        '
        Me.TabPage8.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage8.Controls.Add(Me.DataGridView1)
        Me.TabPage8.Location = New System.Drawing.Point(119, 4)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Size = New System.Drawing.Size(892, 365)
        Me.TabPage8.TabIndex = 4
        Me.TabPage8.Text = "HDD"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5, Me.Column17, Me.Column6})
        Me.DataGridView1.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.ReadOnly = True
        Me.DataGridView1.Size = New System.Drawing.Size(886, 359)
        Me.DataGridView1.TabIndex = 0
        '
        'Column1
        '
        Me.Column1.HeaderText = "Lettre"
        Me.Column1.Name = "Column1"
        Me.Column1.ReadOnly = True
        Me.Column1.Width = 50
        '
        'Column2
        '
        Me.Column2.HeaderText = "Numéro de Série"
        Me.Column2.Name = "Column2"
        Me.Column2.ReadOnly = True
        Me.Column2.Width = 200
        '
        'Column3
        '
        Me.Column3.HeaderText = "Type"
        Me.Column3.Name = "Column3"
        Me.Column3.ReadOnly = True
        Me.Column3.Width = 200
        '
        'Column4
        '
        Me.Column4.HeaderText = "Système de fichier"
        Me.Column4.Name = "Column4"
        Me.Column4.ReadOnly = True
        '
        'Column5
        '
        Me.Column5.HeaderText = "Espace Libre"
        Me.Column5.Name = "Column5"
        Me.Column5.ReadOnly = True
        Me.Column5.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'Column17
        '
        Me.Column17.HeaderText = "Pourcentage"
        Me.Column17.Name = "Column17"
        Me.Column17.ReadOnly = True
        '
        'Column6
        '
        Me.Column6.HeaderText = "Espace Total"
        Me.Column6.Name = "Column6"
        Me.Column6.ReadOnly = True
        '
        'TabPage9
        '
        Me.TabPage9.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage9.Controls.Add(Me.DataGridView2)
        Me.TabPage9.Location = New System.Drawing.Point(119, 4)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Size = New System.Drawing.Size(892, 365)
        Me.TabPage9.TabIndex = 5
        Me.TabPage9.Text = "RESEAU"
        '
        'DataGridView2
        '
        Me.DataGridView2.AllowUserToAddRows = False
        Me.DataGridView2.AllowUserToDeleteRows = False
        Me.DataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.Column7, Me.Column8, Me.Column9, Me.Column10})
        Me.DataGridView2.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.ReadOnly = True
        Me.DataGridView2.Size = New System.Drawing.Size(886, 359)
        Me.DataGridView2.TabIndex = 1
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "Nom"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "Type"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Description"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "@MAC"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.HeaderText = "Vitesse Max"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.HeaderText = "@IP"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        '
        'Column7
        '
        Me.Column7.HeaderText = "Masque sous réseau"
        Me.Column7.Name = "Column7"
        Me.Column7.ReadOnly = True
        '
        'Column8
        '
        Me.Column8.HeaderText = "DHCP"
        Me.Column8.Name = "Column8"
        Me.Column8.ReadOnly = True
        '
        'Column9
        '
        Me.Column9.HeaderText = "@DHCP"
        Me.Column9.Name = "Column9"
        Me.Column9.ReadOnly = True
        '
        'Column10
        '
        Me.Column10.HeaderText = "@DNS"
        Me.Column10.Name = "Column10"
        Me.Column10.ReadOnly = True
        '
        'TabPage10
        '
        Me.TabPage10.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage10.Controls.Add(Me.ListBox1)
        Me.TabPage10.Controls.Add(Me.NsLabel18)
        Me.TabPage10.Location = New System.Drawing.Point(119, 4)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Size = New System.Drawing.Size(892, 365)
        Me.TabPage10.TabIndex = 6
        Me.TabPage10.Text = "UTILISATEURS"
        '
        'ListBox1
        '
        Me.ListBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ListBox1.ForeColor = System.Drawing.Color.White
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(271, 18)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(618, 342)
        Me.ListBox1.TabIndex = 15
        '
        'NsLabel18
        '
        Me.NsLabel18.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel18.Location = New System.Drawing.Point(6, 18)
        Me.NsLabel18.Name = "NsLabel18"
        Me.NsLabel18.Size = New System.Drawing.Size(259, 17)
        Me.NsLabel18.TabIndex = 15
        Me.NsLabel18.Text = "Nom de la carte mère"
        Me.NsLabel18.Value1 = "Liste des utilisateurs"
        Me.NsLabel18.Value2 = ""
        '
        'TabPage11
        '
        Me.TabPage11.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage11.Controls.Add(Me.ListBox2)
        Me.TabPage11.Controls.Add(Me.NsLabel19)
        Me.TabPage11.Location = New System.Drawing.Point(119, 4)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Size = New System.Drawing.Size(892, 365)
        Me.TabPage11.TabIndex = 7
        Me.TabPage11.Text = "GROUPES"
        '
        'ListBox2
        '
        Me.ListBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ListBox2.ForeColor = System.Drawing.Color.White
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Location = New System.Drawing.Point(271, 18)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(618, 342)
        Me.ListBox2.TabIndex = 17
        '
        'NsLabel19
        '
        Me.NsLabel19.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel19.Location = New System.Drawing.Point(6, 18)
        Me.NsLabel19.Name = "NsLabel19"
        Me.NsLabel19.Size = New System.Drawing.Size(259, 17)
        Me.NsLabel19.TabIndex = 17
        Me.NsLabel19.Text = "Nom de la carte mère"
        Me.NsLabel19.Value1 = "Liste des groupes"
        Me.NsLabel19.Value2 = ""
        '
        'TabPage12
        '
        Me.TabPage12.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage12.Controls.Add(Me.TextBox26)
        Me.TabPage12.Controls.Add(Me.NsLabel28)
        Me.TabPage12.Controls.Add(Me.TextBox18)
        Me.TabPage12.Controls.Add(Me.TextBox19)
        Me.TabPage12.Controls.Add(Me.TextBox20)
        Me.TabPage12.Controls.Add(Me.TextBox21)
        Me.TabPage12.Controls.Add(Me.TextBox22)
        Me.TabPage12.Controls.Add(Me.TextBox23)
        Me.TabPage12.Controls.Add(Me.TextBox24)
        Me.TabPage12.Controls.Add(Me.TextBox25)
        Me.TabPage12.Controls.Add(Me.NsLabel20)
        Me.TabPage12.Controls.Add(Me.NsLabel21)
        Me.TabPage12.Controls.Add(Me.NsLabel22)
        Me.TabPage12.Controls.Add(Me.NsLabel23)
        Me.TabPage12.Controls.Add(Me.NsLabel24)
        Me.TabPage12.Controls.Add(Me.NsLabel25)
        Me.TabPage12.Controls.Add(Me.NsLabel26)
        Me.TabPage12.Controls.Add(Me.NsLabel27)
        Me.TabPage12.Location = New System.Drawing.Point(119, 4)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Size = New System.Drawing.Size(892, 365)
        Me.TabPage12.TabIndex = 8
        Me.TabPage12.Text = "STRATEGIE"
        '
        'TextBox26
        '
        Me.TextBox26.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox26.Location = New System.Drawing.Point(271, 200)
        Me.TextBox26.MaxLength = 32767
        Me.TextBox26.Multiline = False
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.ReadOnly = False
        Me.TextBox26.Size = New System.Drawing.Size(405, 23)
        Me.TextBox26.TabIndex = 33
        Me.TextBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox26.UseSystemPasswordChar = False
        '
        'NsLabel28
        '
        Me.NsLabel28.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel28.Location = New System.Drawing.Point(6, 200)
        Me.NsLabel28.Name = "NsLabel28"
        Me.NsLabel28.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel28.TabIndex = 32
        Me.NsLabel28.Text = "NsLabel28"
        Me.NsLabel28.Value1 = "Rôle du poste"
        Me.NsLabel28.Value2 = " "
        '
        'TextBox18
        '
        Me.TextBox18.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox18.Location = New System.Drawing.Point(271, 177)
        Me.TextBox18.MaxLength = 32767
        Me.TextBox18.Multiline = False
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.ReadOnly = False
        Me.TextBox18.Size = New System.Drawing.Size(405, 23)
        Me.TextBox18.TabIndex = 31
        Me.TextBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox18.UseSystemPasswordChar = False
        '
        'TextBox19
        '
        Me.TextBox19.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox19.Location = New System.Drawing.Point(271, 154)
        Me.TextBox19.MaxLength = 32767
        Me.TextBox19.Multiline = False
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.ReadOnly = False
        Me.TextBox19.Size = New System.Drawing.Size(405, 23)
        Me.TextBox19.TabIndex = 30
        Me.TextBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox19.UseSystemPasswordChar = False
        '
        'TextBox20
        '
        Me.TextBox20.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox20.Location = New System.Drawing.Point(271, 131)
        Me.TextBox20.MaxLength = 32767
        Me.TextBox20.Multiline = False
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.ReadOnly = False
        Me.TextBox20.Size = New System.Drawing.Size(405, 23)
        Me.TextBox20.TabIndex = 29
        Me.TextBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox20.UseSystemPasswordChar = False
        '
        'TextBox21
        '
        Me.TextBox21.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox21.Location = New System.Drawing.Point(271, 108)
        Me.TextBox21.MaxLength = 32767
        Me.TextBox21.Multiline = False
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.ReadOnly = False
        Me.TextBox21.Size = New System.Drawing.Size(405, 23)
        Me.TextBox21.TabIndex = 28
        Me.TextBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox21.UseSystemPasswordChar = False
        '
        'TextBox22
        '
        Me.TextBox22.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox22.Location = New System.Drawing.Point(271, 85)
        Me.TextBox22.MaxLength = 32767
        Me.TextBox22.Multiline = False
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.ReadOnly = False
        Me.TextBox22.Size = New System.Drawing.Size(405, 23)
        Me.TextBox22.TabIndex = 27
        Me.TextBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox22.UseSystemPasswordChar = False
        '
        'TextBox23
        '
        Me.TextBox23.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox23.Location = New System.Drawing.Point(271, 64)
        Me.TextBox23.MaxLength = 32767
        Me.TextBox23.Multiline = False
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.ReadOnly = False
        Me.TextBox23.Size = New System.Drawing.Size(405, 23)
        Me.TextBox23.TabIndex = 26
        Me.TextBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox23.UseSystemPasswordChar = False
        '
        'TextBox24
        '
        Me.TextBox24.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox24.Location = New System.Drawing.Point(271, 41)
        Me.TextBox24.MaxLength = 32767
        Me.TextBox24.Multiline = False
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.ReadOnly = False
        Me.TextBox24.Size = New System.Drawing.Size(405, 23)
        Me.TextBox24.TabIndex = 25
        Me.TextBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox24.UseSystemPasswordChar = False
        '
        'TextBox25
        '
        Me.TextBox25.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TextBox25.Location = New System.Drawing.Point(271, 18)
        Me.TextBox25.MaxLength = 32767
        Me.TextBox25.Multiline = False
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.ReadOnly = False
        Me.TextBox25.Size = New System.Drawing.Size(405, 23)
        Me.TextBox25.TabIndex = 24
        Me.TextBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.TextBox25.UseSystemPasswordChar = False
        '
        'NsLabel20
        '
        Me.NsLabel20.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel20.Location = New System.Drawing.Point(6, 154)
        Me.NsLabel20.Name = "NsLabel20"
        Me.NsLabel20.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel20.TabIndex = 23
        Me.NsLabel20.Text = "NsLabel20"
        Me.NsLabel20.Value1 = "Durée du vérrouillage"
        Me.NsLabel20.Value2 = " "
        '
        'NsLabel21
        '
        Me.NsLabel21.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel21.Location = New System.Drawing.Point(6, 177)
        Me.NsLabel21.Name = "NsLabel21"
        Me.NsLabel21.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel21.TabIndex = 22
        Me.NsLabel21.Text = "NsLabel21"
        Me.NsLabel21.Value1 = "Fenêtre d'observation du vérrouillage"
        Me.NsLabel21.Value2 = " "
        '
        'NsLabel22
        '
        Me.NsLabel22.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel22.Location = New System.Drawing.Point(6, 131)
        Me.NsLabel22.Name = "NsLabel22"
        Me.NsLabel22.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel22.TabIndex = 21
        Me.NsLabel22.Text = "NsLabel22"
        Me.NsLabel22.Value1 = "Seuil du vérrouillage"
        Me.NsLabel22.Value2 = " "
        '
        'NsLabel23
        '
        Me.NsLabel23.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel23.Location = New System.Drawing.Point(6, 109)
        Me.NsLabel23.Name = "NsLabel23"
        Me.NsLabel23.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel23.TabIndex = 20
        Me.NsLabel23.Text = "NsLabel23"
        Me.NsLabel23.Value1 = "Nombre de mot de passe anterieur"
        Me.NsLabel23.Value2 = " "
        '
        'NsLabel24
        '
        Me.NsLabel24.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel24.Location = New System.Drawing.Point(6, 86)
        Me.NsLabel24.Name = "NsLabel24"
        Me.NsLabel24.Size = New System.Drawing.Size(342, 17)
        Me.NsLabel24.TabIndex = 19
        Me.NsLabel24.Text = "NsLabel24"
        Me.NsLabel24.Value1 = "Longueur minimal du mot de passe"
        Me.NsLabel24.Value2 = " "
        '
        'NsLabel25
        '
        Me.NsLabel25.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel25.Location = New System.Drawing.Point(6, 64)
        Me.NsLabel25.Name = "NsLabel25"
        Me.NsLabel25.Size = New System.Drawing.Size(216, 21)
        Me.NsLabel25.TabIndex = 18
        Me.NsLabel25.Text = "NsLabel25"
        Me.NsLabel25.Value1 = "Mot de passe vie maximale"
        Me.NsLabel25.Value2 = " "
        '
        'NsLabel26
        '
        Me.NsLabel26.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel26.Location = New System.Drawing.Point(6, 41)
        Me.NsLabel26.Name = "NsLabel26"
        Me.NsLabel26.Size = New System.Drawing.Size(216, 17)
        Me.NsLabel26.TabIndex = 17
        Me.NsLabel26.Text = "NsLabel26"
        Me.NsLabel26.Value1 = "Mot de passe vie minimale"
        Me.NsLabel26.Value2 = " "
        '
        'NsLabel27
        '
        Me.NsLabel27.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel27.Location = New System.Drawing.Point(6, 18)
        Me.NsLabel27.Name = "NsLabel27"
        Me.NsLabel27.Size = New System.Drawing.Size(127, 17)
        Me.NsLabel27.TabIndex = 16
        Me.NsLabel27.Text = "Nom du poste"
        Me.NsLabel27.Value1 = "Expiration"
        Me.NsLabel27.Value2 = ""
        '
        'TabPage13
        '
        Me.TabPage13.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage13.Controls.Add(Me.ListBox3)
        Me.TabPage13.Controls.Add(Me.NsLabel29)
        Me.TabPage13.Location = New System.Drawing.Point(119, 4)
        Me.TabPage13.Name = "TabPage13"
        Me.TabPage13.Size = New System.Drawing.Size(892, 365)
        Me.TabPage13.TabIndex = 9
        Me.TabPage13.Text = "LOGICIELS"
        '
        'ListBox3
        '
        Me.ListBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ListBox3.ForeColor = System.Drawing.Color.White
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.Location = New System.Drawing.Point(271, 18)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(618, 342)
        Me.ListBox3.TabIndex = 17
        '
        'NsLabel29
        '
        Me.NsLabel29.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel29.Location = New System.Drawing.Point(6, 18)
        Me.NsLabel29.Name = "NsLabel29"
        Me.NsLabel29.Size = New System.Drawing.Size(259, 17)
        Me.NsLabel29.TabIndex = 19
        Me.NsLabel29.Text = "Nom de la carte mère"
        Me.NsLabel29.Value1 = "Liste des Logiciels"
        Me.NsLabel29.Value2 = ""
        '
        'TabPage14
        '
        Me.TabPage14.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage14.Controls.Add(Me.ListBox4)
        Me.TabPage14.Controls.Add(Me.NsLabel30)
        Me.TabPage14.Location = New System.Drawing.Point(119, 4)
        Me.TabPage14.Name = "TabPage14"
        Me.TabPage14.Size = New System.Drawing.Size(892, 365)
        Me.TabPage14.TabIndex = 10
        Me.TabPage14.Text = "PILOTES"
        '
        'ListBox4
        '
        Me.ListBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ListBox4.ForeColor = System.Drawing.Color.White
        Me.ListBox4.FormattingEnabled = True
        Me.ListBox4.Location = New System.Drawing.Point(271, 18)
        Me.ListBox4.Name = "ListBox4"
        Me.ListBox4.Size = New System.Drawing.Size(618, 342)
        Me.ListBox4.TabIndex = 17
        '
        'NsLabel30
        '
        Me.NsLabel30.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel30.Location = New System.Drawing.Point(6, 18)
        Me.NsLabel30.Name = "NsLabel30"
        Me.NsLabel30.Size = New System.Drawing.Size(259, 17)
        Me.NsLabel30.TabIndex = 21
        Me.NsLabel30.Text = "Nom de la carte mère"
        Me.NsLabel30.Value1 = "Liste des Logiciels"
        Me.NsLabel30.Value2 = ""
        '
        'TabPage15
        '
        Me.TabPage15.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage15.Controls.Add(Me.DataGridView3)
        Me.TabPage15.Location = New System.Drawing.Point(119, 4)
        Me.TabPage15.Name = "TabPage15"
        Me.TabPage15.Size = New System.Drawing.Size(892, 365)
        Me.TabPage15.TabIndex = 11
        Me.TabPage15.Text = "SERVICES"
        '
        'DataGridView3
        '
        Me.DataGridView3.AllowUserToAddRows = False
        Me.DataGridView3.AllowUserToDeleteRows = False
        Me.DataGridView3.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11})
        Me.DataGridView3.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.ReadOnly = True
        Me.DataGridView3.Size = New System.Drawing.Size(886, 359)
        Me.DataGridView3.TabIndex = 2
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.HeaderText = "Nom"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Width = 150
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.HeaderText = "Descritpion"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Width = 400
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.HeaderText = "Statut"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "Etat"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.HeaderText = "Code Sortie"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.ReadOnly = True
        '
        'TabPage16
        '
        Me.TabPage16.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage16.Controls.Add(Me.DataGridView4)
        Me.TabPage16.Location = New System.Drawing.Point(119, 4)
        Me.TabPage16.Name = "TabPage16"
        Me.TabPage16.Size = New System.Drawing.Size(892, 365)
        Me.TabPage16.TabIndex = 12
        Me.TabPage16.Text = "MAJ"
        '
        'DataGridView4
        '
        Me.DataGridView4.AllowUserToAddRows = False
        Me.DataGridView4.AllowUserToDeleteRows = False
        Me.DataGridView4.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18, Me.DataGridViewTextBoxColumn19, Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn23})
        Me.DataGridView4.Location = New System.Drawing.Point(3, 3)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.ReadOnly = True
        Me.DataGridView4.Size = New System.Drawing.Size(886, 359)
        Me.DataGridView4.TabIndex = 4
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.HeaderText = "Nom"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.ReadOnly = True
        Me.DataGridViewTextBoxColumn17.Width = 300
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "Poste"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.ReadOnly = True
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.HeaderText = "Description"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.ReadOnly = True
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.HeaderText = "N° de KB"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.ReadOnly = True
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.HeaderText = "Installé par"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.ReadOnly = True
        Me.DataGridViewTextBoxColumn22.Width = 150
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.HeaderText = "Date d'installation"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        Me.DataGridViewTextBoxColumn23.ReadOnly = True
        '
        'NsLabel34
        '
        Me.NsLabel34.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel34.Location = New System.Drawing.Point(354, 12)
        Me.NsLabel34.Name = "NsLabel34"
        Me.NsLabel34.Size = New System.Drawing.Size(168, 23)
        Me.NsLabel34.TabIndex = 3
        Me.NsLabel34.Text = "NsLabel34"
        Me.NsLabel34.Value1 = "Audit"
        Me.NsLabel34.Value2 = ""
        '
        'ComboBox1
        '
        Me.ComboBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox1.ForeColor = System.Drawing.Color.White
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(124, 12)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(224, 21)
        Me.ComboBox1.TabIndex = 2
        '
        'NsLabel33
        '
        Me.NsLabel33.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel33.Location = New System.Drawing.Point(12, 12)
        Me.NsLabel33.Name = "NsLabel33"
        Me.NsLabel33.Size = New System.Drawing.Size(168, 23)
        Me.NsLabel33.TabIndex = 1
        Me.NsLabel33.Text = "NsLabel33"
        Me.NsLabel33.Value1 = "Nom du serveur"
        Me.NsLabel33.Value2 = ""
        '
        'TabPage18
        '
        Me.TabPage18.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage18.Controls.Add(Me.ComboBox3)
        Me.TabPage18.Controls.Add(Me.DataGridView5)
        Me.TabPage18.Controls.Add(Me.DateTimePicker1)
        Me.TabPage18.Controls.Add(Me.NsLabel32)
        Me.TabPage18.Controls.Add(Me.NsLabel31)
        Me.TabPage18.Location = New System.Drawing.Point(119, 4)
        Me.TabPage18.Name = "TabPage18"
        Me.TabPage18.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage18.Size = New System.Drawing.Size(1044, 454)
        Me.TabPage18.TabIndex = 1
        Me.TabPage18.Text = "Comparaison"
        '
        'ComboBox3
        '
        Me.ComboBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.ComboBox3.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed
        Me.ComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox3.ForeColor = System.Drawing.Color.White
        Me.ComboBox3.FormattingEnabled = True
        Me.ComboBox3.Location = New System.Drawing.Point(191, 12)
        Me.ComboBox3.Name = "ComboBox3"
        Me.ComboBox3.Size = New System.Drawing.Size(235, 21)
        Me.ComboBox3.TabIndex = 2
        '
        'DataGridView5
        '
        Me.DataGridView5.AllowUserToAddRows = False
        Me.DataGridView5.AllowUserToDeleteRows = False
        Me.DataGridView5.AllowUserToOrderColumns = True
        Me.DataGridView5.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView5.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column12})
        Me.DataGridView5.Location = New System.Drawing.Point(13, 70)
        Me.DataGridView5.Name = "DataGridView5"
        Me.DataGridView5.ReadOnly = True
        Me.DataGridView5.Size = New System.Drawing.Size(1025, 378)
        Me.DataGridView5.TabIndex = 12
        '
        'Column12
        '
        Me.Column12.HeaderText = "Champ"
        Me.Column12.Name = "Column12"
        Me.Column12.ReadOnly = True
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.CalendarMonthBackground = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DateTimePicker1.CalendarTitleBackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DateTimePicker1.Location = New System.Drawing.Point(191, 39)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(235, 20)
        Me.DateTimePicker1.TabIndex = 13
        '
        'NsLabel32
        '
        Me.NsLabel32.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel32.Location = New System.Drawing.Point(12, 41)
        Me.NsLabel32.Name = "NsLabel32"
        Me.NsLabel32.Size = New System.Drawing.Size(168, 23)
        Me.NsLabel32.TabIndex = 1
        Me.NsLabel32.Text = "NsLabel32"
        Me.NsLabel32.Value1 = "Elément de comparaison"
        Me.NsLabel32.Value2 = ""
        '
        'NsLabel31
        '
        Me.NsLabel31.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel31.Location = New System.Drawing.Point(12, 12)
        Me.NsLabel31.Name = "NsLabel31"
        Me.NsLabel31.Size = New System.Drawing.Size(168, 23)
        Me.NsLabel31.TabIndex = 0
        Me.NsLabel31.Text = "NsLabel31"
        Me.NsLabel31.Value1 = "Elément de comparaison"
        Me.NsLabel31.Value2 = ""
        '
        'TabPage19
        '
        Me.TabPage19.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.TabPage19.Controls.Add(Me.DataGridView6)
        Me.TabPage19.Location = New System.Drawing.Point(119, 4)
        Me.TabPage19.Name = "TabPage19"
        Me.TabPage19.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage19.Size = New System.Drawing.Size(1044, 454)
        Me.TabPage19.TabIndex = 2
        Me.TabPage19.Text = "Surveillance"
        '
        'DataGridView6
        '
        Me.DataGridView6.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView6.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column11, Me.Column13, Me.Column14, Me.Column15, Me.Column16})
        Me.DataGridView6.Location = New System.Drawing.Point(6, 3)
        Me.DataGridView6.Name = "DataGridView6"
        Me.DataGridView6.Size = New System.Drawing.Size(1032, 445)
        Me.DataGridView6.TabIndex = 0
        '
        'Column11
        '
        Me.Column11.HeaderText = "#"
        Me.Column11.Name = "Column11"
        Me.Column11.ReadOnly = True
        '
        'Column13
        '
        Me.Column13.HeaderText = "Description"
        Me.Column13.Name = "Column13"
        Me.Column13.ReadOnly = True
        Me.Column13.Width = 500
        '
        'Column14
        '
        Me.Column14.HeaderText = "Date"
        Me.Column14.Name = "Column14"
        '
        'Column15
        '
        Me.Column15.HeaderText = "Heure"
        Me.Column15.Name = "Column15"
        '
        'Column16
        '
        Me.Column16.HeaderText = "Niveau"
        Me.Column16.Name = "Column16"
        Me.Column16.ReadOnly = True
        '
        'NsTheme1
        '
        Me.NsTheme1.AccentOffset = 42
        Me.NsTheme1.BackColor = System.Drawing.Color.FromArgb(CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer), CType(CType(50, Byte), Integer))
        Me.NsTheme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.NsTheme1.Colors = New WindowsApplication1.Bloom(-1) {}
        Me.NsTheme1.Controls.Add(Me.NsLabel38)
        Me.NsTheme1.Controls.Add(Me.NsProgressBar1)
        Me.NsTheme1.Controls.Add(Me.NsButton3)
        Me.NsTheme1.Controls.Add(Me.NsLabel36)
        Me.NsTheme1.Controls.Add(Me.NsSeperator1)
        Me.NsTheme1.Customization = ""
        Me.NsTheme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.NsTheme1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.NsTheme1.Image = Nothing
        Me.NsTheme1.Location = New System.Drawing.Point(0, 0)
        Me.NsTheme1.Movable = True
        Me.NsTheme1.Name = "NsTheme1"
        Me.NsTheme1.NoRounding = False
        Me.NsTheme1.Sizable = True
        Me.NsTheme1.Size = New System.Drawing.Size(1184, 563)
        Me.NsTheme1.SmartBounds = True
        Me.NsTheme1.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.NsTheme1.TabIndex = 10
        Me.NsTheme1.TransparencyKey = System.Drawing.Color.Empty
        Me.NsTheme1.Transparent = True
        '
        'NsLabel38
        '
        Me.NsLabel38.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NsLabel38.Location = New System.Drawing.Point(846, 542)
        Me.NsLabel38.Name = "NsLabel38"
        Me.NsLabel38.Size = New System.Drawing.Size(144, 18)
        Me.NsLabel38.TabIndex = 15
        Me.NsLabel38.Text = "NsLabel38"
        Me.NsLabel38.Value1 = "Chargement de la base"
        Me.NsLabel38.Value2 = ""
        '
        'NsProgressBar1
        '
        Me.NsProgressBar1.Location = New System.Drawing.Point(987, 544)
        Me.NsProgressBar1.Maximum = 100
        Me.NsProgressBar1.Minimum = 0
        Me.NsProgressBar1.Name = "NsProgressBar1"
        Me.NsProgressBar1.Size = New System.Drawing.Size(192, 15)
        Me.NsProgressBar1.TabIndex = 13
        Me.NsProgressBar1.Text = "NsProgressBar1"
        Me.NsProgressBar1.Value = 0
        '
        'NsButton3
        '
        Me.NsButton3.Location = New System.Drawing.Point(1160, 3)
        Me.NsButton3.Name = "NsButton3"
        Me.NsButton3.Size = New System.Drawing.Size(21, 22)
        Me.NsButton3.TabIndex = 12
        Me.NsButton3.Text = "X"
        '
        'NsLabel36
        '
        Me.NsLabel36.Font = New System.Drawing.Font("Segoe UI", 10.0!, System.Drawing.FontStyle.Bold)
        Me.NsLabel36.Location = New System.Drawing.Point(13, 3)
        Me.NsLabel36.Name = "NsLabel36"
        Me.NsLabel36.Size = New System.Drawing.Size(87, 23)
        Me.NsLabel36.TabIndex = 11
        Me.NsLabel36.Text = "NsLabel36"
        Me.NsLabel36.Value1 = "AUDIT"
        Me.NsLabel36.Value2 = "0.1"
        '
        'NsSeperator1
        '
        Me.NsSeperator1.Location = New System.Drawing.Point(3, 536)
        Me.NsSeperator1.Name = "NsSeperator1"
        Me.NsSeperator1.Size = New System.Drawing.Size(1176, 23)
        Me.NsSeperator1.TabIndex = 14
        Me.NsSeperator1.Text = "NsSeperator1"
        '
        'Principale
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1184, 563)
        Me.Controls.Add(Me.NsLabel35)
        Me.Controls.Add(Me.NsOnOffBox1)
        Me.Controls.Add(Me.NsButton2)
        Me.Controls.Add(Me.NsButton1)
        Me.Controls.Add(Me.NsTabControl2)
        Me.Controls.Add(Me.NsTheme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Principale"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Audit"
        Me.NsTabControl2.ResumeLayout(False)
        Me.TabPage17.ResumeLayout(False)
        Me.NsTabControl1.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage7.ResumeLayout(False)
        Me.TabPage8.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage9.ResumeLayout(False)
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage10.ResumeLayout(False)
        Me.TabPage11.ResumeLayout(False)
        Me.TabPage12.ResumeLayout(False)
        Me.TabPage13.ResumeLayout(False)
        Me.TabPage14.ResumeLayout(False)
        Me.TabPage15.ResumeLayout(False)
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage16.ResumeLayout(False)
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage18.ResumeLayout(False)
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage19.ResumeLayout(False)
        CType(Me.DataGridView6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.NsTheme1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents Column7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DateTimePicker1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents DataGridView5 As System.Windows.Forms.DataGridView
    Friend WithEvents Column12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridView2 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FolderBrowserDialog1 As System.Windows.Forms.FolderBrowserDialog
    Friend WithEvents DataGridView6 As System.Windows.Forms.DataGridView
    Friend WithEvents Column11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Column16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents NsTabControl1 As NSTabControl
    Friend WithEvents TabPage4 As TabPage
    Friend WithEvents TabPage5 As TabPage
    Friend WithEvents TabPage6 As TabPage
    Friend WithEvents TabPage7 As TabPage
    Friend WithEvents TabPage8 As TabPage
    Friend WithEvents TabPage9 As TabPage
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents TextBox8 As NSTextBox
    Friend WithEvents TextBox7 As NSTextBox
    Friend WithEvents TextBox6 As NSTextBox
    Friend WithEvents TextBox5 As NSTextBox
    Friend WithEvents TextBox4 As NSTextBox
    Friend WithEvents TextBox3 As NSTextBox
    Friend WithEvents TextBox2 As NSTextBox
    Friend WithEvents TextBox1 As NSTextBox
    Friend WithEvents NsLabel8 As NSLabel
    Friend WithEvents NsLabel7 As NSLabel
    Friend WithEvents NsLabel4 As NSLabel
    Friend WithEvents NsLabel5 As NSLabel
    Friend WithEvents NsLabel6 As NSLabel
    Friend WithEvents NsLabel3 As NSLabel
    Friend WithEvents NsLabel2 As NSLabel
    Friend WithEvents NsLabel1 As NSLabel
    Friend WithEvents TextBox9 As NSTextBox
    Friend WithEvents TextBox10 As NSTextBox
    Friend WithEvents TextBox11 As NSTextBox
    Friend WithEvents NsLabel9 As NSLabel
    Friend WithEvents NsLabel10 As NSLabel
    Friend WithEvents NsLabel11 As NSLabel
    Friend WithEvents TextBox16 As NSTextBox
    Friend WithEvents TextBox15 As NSTextBox
    Friend WithEvents TextBox12 As NSTextBox
    Friend WithEvents TextBox13 As NSTextBox
    Friend WithEvents TextBox14 As NSTextBox
    Friend WithEvents NsLabel12 As NSLabel
    Friend WithEvents NsLabel13 As NSLabel
    Friend WithEvents NsLabel14 As NSLabel
    Friend WithEvents NsLabel15 As NSLabel
    Friend WithEvents NsLabel16 As NSLabel
    Friend WithEvents TextBox17 As NSTextBox
    Friend WithEvents NsLabel17 As NSLabel
    Friend WithEvents TabPage10 As TabPage
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents NsLabel18 As NSLabel
    Friend WithEvents TabPage11 As TabPage
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents NsLabel19 As NSLabel
    Friend WithEvents TabPage12 As TabPage
    Friend WithEvents TextBox26 As NSTextBox
    Friend WithEvents NsLabel28 As NSLabel
    Friend WithEvents TextBox18 As NSTextBox
    Friend WithEvents TextBox19 As NSTextBox
    Friend WithEvents TextBox20 As NSTextBox
    Friend WithEvents TextBox21 As NSTextBox
    Friend WithEvents TextBox22 As NSTextBox
    Friend WithEvents TextBox23 As NSTextBox
    Friend WithEvents TextBox24 As NSTextBox
    Friend WithEvents TextBox25 As NSTextBox
    Friend WithEvents NsLabel20 As NSLabel
    Friend WithEvents NsLabel21 As NSLabel
    Friend WithEvents NsLabel22 As NSLabel
    Friend WithEvents NsLabel23 As NSLabel
    Friend WithEvents NsLabel24 As NSLabel
    Friend WithEvents NsLabel25 As NSLabel
    Friend WithEvents NsLabel26 As NSLabel
    Friend WithEvents NsLabel27 As NSLabel
    Friend WithEvents TabPage13 As TabPage
    Friend WithEvents ListBox3 As ListBox
    Friend WithEvents NsLabel29 As NSLabel
    Friend WithEvents TabPage14 As TabPage
    Friend WithEvents ListBox4 As ListBox
    Friend WithEvents NsLabel30 As NSLabel
    Friend WithEvents TabPage15 As TabPage
    Friend WithEvents TabPage16 As TabPage
    Friend WithEvents DataGridView4 As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As DataGridViewTextBoxColumn
    Friend WithEvents NsTabControl2 As NSTabControl
    Friend WithEvents TabPage17 As TabPage
    Friend WithEvents ComboBox2 As NSComboBox
    Friend WithEvents NsLabel34 As NSLabel
    Friend WithEvents ComboBox1 As NSComboBox
    Friend WithEvents NsLabel33 As NSLabel
    Friend WithEvents TabPage18 As TabPage
    Friend WithEvents ComboBox3 As NSComboBox
    Friend WithEvents NsLabel32 As NSLabel
    Friend WithEvents NsLabel31 As NSLabel
    Friend WithEvents TabPage19 As TabPage
    Friend WithEvents NsButton1 As NSButton
    Friend WithEvents NsButton2 As NSButton
    Friend WithEvents NsOnOffBox1 As NSOnOffBox
    Friend WithEvents NsLabel35 As NSLabel
    Friend WithEvents NsTheme1 As NSTheme
    Friend WithEvents NsButton3 As NSButton
    Friend WithEvents NsLabel36 As NSLabel
    Friend WithEvents NsTextBox1 As NSTextBox
    Friend WithEvents NsLabel37 As NSLabel
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Column17 As DataGridViewProgressColumn
    Friend WithEvents Column6 As DataGridViewTextBoxColumn
    Friend WithEvents NsProgressBar1 As NSProgressBar
    Friend WithEvents NsLabel38 As NSLabel
    Friend WithEvents NsSeperator1 As NSSeperator
End Class
